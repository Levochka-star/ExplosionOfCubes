﻿using System;
using System.Text;

namespace ДЗ_Вывод_имени
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.InputEncoding = Encoding.Unicode;
            Console.OutputEncoding = Encoding.Unicode;

            string symbol = "символ";
            string sumbolStrings = "";
            string middleLine;
            string userName = "имя";

            Console.Write($"Введите желаемый {symbol}: ");
            symbol = Console.ReadLine();

            Console.Write($"Введите {userName}: ");
            userName = Console.ReadLine();

            middleLine = symbol + userName + symbol;

            for (int i = 0; i < middleLine.Length; i++)
            {
                sumbolStrings += symbol;
            }

            Console.WriteLine($"{sumbolStrings}\n" +
                $"{middleLine}\n" +
                $"{sumbolStrings}");

            Console.ReadKey();
        }
    }
}