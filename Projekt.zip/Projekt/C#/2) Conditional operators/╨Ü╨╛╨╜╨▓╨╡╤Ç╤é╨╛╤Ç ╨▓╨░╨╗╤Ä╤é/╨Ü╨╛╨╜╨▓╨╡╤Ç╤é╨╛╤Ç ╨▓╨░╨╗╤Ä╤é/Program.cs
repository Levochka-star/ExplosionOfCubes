﻿using System;
using System.Text;

namespace Конвертор_валют
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string CommandShowRubToUsd = "1";
            const string CommandShowUsdToRub = "2";
            const string CommandShowRubToJpy = "3";
            const string CommandShowJpyToRub = "4";
            const string CommandShowJpyToUsd = "5";
            const string CommandShowUsdToJpy = "6";
            const string CommandConsoleClear = "7";
            const string CommandExit = "8";

            Console.InputEncoding = Encoding.Unicode;
            Console.OutputEncoding = Encoding.Unicode;

            bool isWork = true;

            float balanceRub = 50000;
            string rubName = "рубль";
            string signRub = "₽";
            float balanceUsd = 1000;
            string usdName = "доллар";
            string signUsd = "$";
            float balanceJpy = 200000;
            string jpyName = "йену";
            string signJpy = "¥";
            string failConvert = "Перепроверьте введенные данные.";
            float currencyUnit;
            string convertCurrency;
            bool canConvert;

            float costConversionRubToUsd = 86;
            float costConversionUsdToRub = 83;
            float costConversionRubToJpy = 0.7f;
            float costConversionJpyToRub = 0.6f;
            float costConversionJpyToUsd = 147;
            float costConversionUsdToJpy = 146;

            Console.Write("Добро пожаловать в конвертер валют!\n");

            while (isWork)
            {
                Console.WriteLine($"\nУ вас в электронном кошельке:\n{balanceRub}{signRub} {balanceUsd}{signUsd} {balanceJpy}{signJpy}");

                Console.WriteLine($"\nКакую валютную пару желаете конвертировать?\n" +
                    $"{CommandShowRubToUsd} - {rubName} в {usdName}.\n" +
                    $"{CommandShowUsdToRub} - {usdName} в {rubName}.\n" +
                    $"{CommandShowRubToJpy} - {rubName} в {jpyName}.\n" +
                    $"{CommandShowJpyToRub} - {jpyName} в {rubName}.\n" +
                    $"{CommandShowJpyToUsd} - {jpyName} в {usdName}.\n" +
                    $"{CommandShowUsdToJpy} - {usdName} в {jpyName}.\n" +
                    $"{CommandConsoleClear} - Если желаете очистить консоль.\n" +
                    $"{CommandExit} - Если желаете выйти.\n");

                convertCurrency = Console.ReadLine();

                if (convertCurrency == CommandConsoleClear)
                {
                    Console.Clear();
                    continue;
                }
                else if (convertCurrency == CommandExit)
                {
                    isWork = false;
                    continue;
                }

                Console.WriteLine($"\nСколько единиц валюты желаете конвертировать?\n");
                currencyUnit = Convert.ToSingle(Console.ReadLine());

                switch (convertCurrency)
                {
                    case CommandShowRubToUsd:
                        canConvert = balanceRub >= currencyUnit;
                        balanceRub -= Convert.ToSingle(canConvert) * currencyUnit;
                        balanceUsd += (Convert.ToSingle(canConvert) * currencyUnit) / costConversionRubToUsd;
                        break;

                    case CommandShowUsdToRub:
                        canConvert = balanceUsd >= currencyUnit;
                        balanceUsd -= Convert.ToSingle(canConvert) * currencyUnit;
                        balanceRub += (Convert.ToSingle(canConvert) * currencyUnit) * costConversionUsdToRub;
                        break;

                    case CommandShowRubToJpy:
                        canConvert = balanceRub >= currencyUnit;
                        balanceRub -= Convert.ToSingle(canConvert) * currencyUnit;
                        balanceJpy += (Convert.ToSingle(canConvert) * currencyUnit) / costConversionRubToJpy;
                        break;

                    case CommandShowJpyToRub:
                        canConvert = balanceRub >= currencyUnit;
                        balanceJpy -= Convert.ToSingle(canConvert) * currencyUnit;
                        balanceRub += (Convert.ToSingle(canConvert) * currencyUnit) * costConversionJpyToRub;
                        break;

                    case CommandShowJpyToUsd:
                        canConvert = balanceRub >= currencyUnit;
                        balanceJpy -= Convert.ToSingle(canConvert) * currencyUnit;
                        balanceUsd += (Convert.ToSingle(canConvert) * currencyUnit) / costConversionJpyToUsd;
                        break;

                    case CommandShowUsdToJpy:
                        canConvert = balanceRub >= currencyUnit;
                        balanceUsd -= Convert.ToSingle(canConvert) * currencyUnit;
                        balanceJpy += (Convert.ToSingle(canConvert) * currencyUnit) * costConversionUsdToJpy;
                        break;

                    default:
                        Console.WriteLine(failConvert);
                        break;
                }
            }
        }
    }
}