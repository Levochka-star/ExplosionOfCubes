﻿using System;

namespace ДЗ_консольноеМеню
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string CommandShowStory1 = "1";
            const string CommandShowStory2 = "2";
            const string CommandRandomNumber = "3";

            Random random = new Random();
            int randomNumberStart = 0;
            int randomNumberEnd = 999;

            bool isWork = true;
            string numberMenuItem4 = "4";
            string numberMenuItem5 = "5";
            string selectionUserNumber;

            string nameStory1 = "\"Россия\"";
            string story1 = "Россия — крупнейшее в мире государство, расположенное \n" +
                        "на северо - востоке Евразии.Страна занимает площадь около \n" +
                        "17 миллионов квадратных километров и граничит с восемнадцатью \n" +
                        "странами.\n";
            string nameStory2 = "\"Фотосфера солнца\"";
            string story2 = "Фотосфера образует видимую поверхность Солнца, по которой \n" +
                        "определяются размеры Солнца, расстояние от Солнца и т. д.. \n" +
                        "Температура в фотосфере относительно «прохладная» — около \n" +
                        "5 500 градусов Цельсия. Именно в этом слое появляются тёмные \n" +
                        "солнечные пятна, вызванные изменениями в магнитном поле.\n";

            Console.WriteLine($"Добро пожаловать!\n");

            while (isWork)
            {
                int randNumber = random.Next(randomNumberStart, randomNumberEnd);

                Console.WriteLine($"Выберите желаемый из пунктов:\n" +
                    $"{CommandShowStory1}. Желаете услышать рассказ {nameStory1}?\n" +
                    $"{CommandShowStory2}. Желаете услышать рассказ {nameStory2}?\n" +
                    $"{CommandRandomNumber}. Желаете увидеть случайное число?\n" +
                    $"{numberMenuItem4}. Чтоб очистить командную строку.\n" +
                    $"{numberMenuItem5}. Чтоб закрыть программу.\n");

                selectionUserNumber = Console.ReadLine();
                Console.WriteLine("\n");

                switch (selectionUserNumber)
                {
                   case CommandShowStory1:
                        Console.WriteLine(story1);
                        break;
                   case CommandShowStory2:
                        Console.WriteLine(story2);
                        break;
                   case CommandRandomNumber:
                    Console.WriteLine($"Ваше число: {randNumber}.\n");
                        break;
                   default:
                        Console.WriteLine($"Такого пункта нет, введите номер пункта для корректной работы.\n");
                        break;
                }

                if (selectionUserNumber == numberMenuItem4)
                {
                    Console.Clear();
                }
                else if (selectionUserNumber == numberMenuItem5)
                {
                    isWork = false;
                }
            }
        }
    }
}