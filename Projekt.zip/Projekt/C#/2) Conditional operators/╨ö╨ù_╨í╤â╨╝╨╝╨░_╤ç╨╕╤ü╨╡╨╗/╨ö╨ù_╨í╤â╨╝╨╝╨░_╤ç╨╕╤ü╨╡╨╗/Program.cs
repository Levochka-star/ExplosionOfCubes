﻿using System;

namespace ДЗ_Сумма_чисел
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            int multipleNumber1 = 3;
            int multipleNumber2 = 5;
            int sumMultiple = 0;
            int numberStart = 0;
            int numberEnd = 101;
            int number = random.Next(numberStart, numberEnd);

            for (int i = numberStart; i <= number; i++)
            {
                bool canSumNumber1 = (i % multipleNumber1) == 0;
                bool canSumNumber2 = (i % multipleNumber2) == 0;

                if (canSumNumber1 == true || canSumNumber2 == true)
                {
                    sumMultiple += i;
                }
            }

            Console.WriteLine($"Для {number}, суммой кратных {multipleNumber1} и " +
                $"{multipleNumber2} цифрам, приходится число {sumMultiple}.");
            Console.ReadKey();
        }
    }
}