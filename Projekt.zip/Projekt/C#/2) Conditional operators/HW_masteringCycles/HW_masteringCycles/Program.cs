﻿using System;
using System.Text;

namespace HW_masteringCycles
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.InputEncoding = Encoding.Unicode;
            Console.OutputEncoding = Encoding.Unicode;

            string userMessage;
            int repeatCount;

            Console.Write("Введите сообщение: ");
            userMessage = Console.ReadLine();
            Console.Write("Введите количество повторений: ");
            repeatCount = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < repeatCount; i++)
            {
                Console.WriteLine(userMessage);
            }
            
            Console.ReadKey();
        }
    }
}