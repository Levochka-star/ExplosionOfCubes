﻿using System;

namespace ДЗ_Степень_двойки
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            int startRandomNumber = 1;
            int endRandomNumber = 999;
            int number = random.Next(startRandomNumber, endRandomNumber);
            int numberForLookingDegree = 2;
            int degrees = 1;
            int numberDegree = 2;

            bool isWork = true;

            while (isWork)
            {
                if (numberDegree <= number)
                {
                    numberDegree *= numberForLookingDegree;
                    degrees++;
                }
                else
                {
                    isWork = false;
                }
            }

            Console.WriteLine($"В консоль вывести число {numberDegree}, которое больше рандомного числа {number}.\n" +
                $"{numberDegree} это {numberForLookingDegree} в {degrees} степени.");
            Console.ReadKey();
        }
    }
}
