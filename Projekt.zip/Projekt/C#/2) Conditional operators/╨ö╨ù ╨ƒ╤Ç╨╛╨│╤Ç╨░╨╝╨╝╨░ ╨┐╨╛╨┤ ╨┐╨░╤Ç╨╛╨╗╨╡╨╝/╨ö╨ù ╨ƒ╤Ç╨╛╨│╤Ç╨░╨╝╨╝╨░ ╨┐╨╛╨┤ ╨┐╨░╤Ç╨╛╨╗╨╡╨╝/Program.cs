﻿using System;

namespace ДЗ_Программа_под_паролем
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string password;
            string passwordCheck;
            int inputTry = 3;

            Console.Write("Введите пароль для программы: ");
            password = Console.ReadLine();
            Console.Clear();

            Console.Write("Введите пароль для доступа к секретному сообщению: ");
            passwordCheck = Console.ReadLine();

            for (int i = 0; i < inputTry; i++)
            {
                if (passwordCheck == password)
                {
                    Console.WriteLine("Тайное сообщение: вы ввели верный пароль!");
                    Console.ReadKey();
                    i = inputTry;
                }
                else
                {
                    Console.WriteLine("Пароль неверный, введите пароль еще раз!");
                    passwordCheck = Console.ReadLine();
                }
            }
        }
    }
}
