﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _22_игра_гладиаторские_бои
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Задача: у нас есть два гладиатора с рандомными значениями здоровья, урона и брони.
            //сделать гладиаторские бои

            Random rand = new Random();

            //int trys = 100;
            float health1 = rand.Next(50, 100);
            int damage1 = rand.Next(20, 100);
            int armor1 = rand.Next(10, 100);

            float health2 = rand.Next(50, 100);
            int damage2 = rand.Next(20, 100);
            int armor2 = rand.Next(10, 100);

            Console.WriteLine($"Гладиатор 1 - {health1} здоровья, {damage1} наносимый урон, {armor1} броня.");
            Console.WriteLine($"Гладиатор 2 - {health2} здоровья, {damage2} наносимый урон, {armor2} броня.");

            //while (trys-- > 0)
            while(health1 > 0 && health2 > 0)
            {
                health1 -= Convert.ToSingle(rand.Next(0, damage2 + 1)) / 100 * armor1;
                health2 -= Convert.ToSingle(rand.Next(0, damage1 + 1)) / 100 * armor2;
                Console.WriteLine("Здоровье гладиатора 1: " + health1);
                Console.WriteLine("Здоровье гладиатора 2: " + health2);
            }

            if (health1 <= 0 && health2 <= 0)
            {
                Console.WriteLine("Ничья. Оба гладиатора погибли:'(");
            }
            else if (health1 <= 0)
            {
                Console.WriteLine("Гладиатор 1 пал.");
            }
            else if (health2 <= 0)
            {
                Console.WriteLine("Гладиатор 2 пал.");
            }
            Console.ReadKey();
        }
    }
}
