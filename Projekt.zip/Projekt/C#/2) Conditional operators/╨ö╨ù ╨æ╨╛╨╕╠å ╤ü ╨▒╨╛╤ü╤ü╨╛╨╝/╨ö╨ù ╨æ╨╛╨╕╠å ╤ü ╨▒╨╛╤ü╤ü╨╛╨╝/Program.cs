﻿using System;

namespace ДЗ_Бой_с_боссом
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string CommandDefaultAttackPlayer = "1";
            const string CommandFireballAttackPlayer = "2";
            const string CommandExplosionAttackPlayer = "3";
            const string CommandHealingPlayer = "4";

            Random random = new Random();

            int healtEnemyAfterBlow = 0;
            int healthEnemy = 425;

            int attackEnemy;
            int minValueAttackEnemy = 10;
            int maxValueAttackEnemy = 24;

            int maxHealthPlayer = 150;
            int healthPlayer = 150;
            int maxManaPlayer = 30;
            int manaPlayer = 0;
            int recoveryHealth = 15;
            int recoveryMana = 4;
            int amountHealing = 4;
            int amountAplicationsHealing = 1;

            int manaPerFireball = 9;
            int manaPerExplosion = 30;
            int counterFireball = 0;

            int defaultAttackPlayer;
            int minValueDefaultAttackPlayer = 20;
            int maxValueDefaultAttackPlayer = 30;
            int fireballAttackPlayer;
            int minValueFireballAttackPlayer = 30;
            int maxValueFireballAttackPlayer = 50;
            int explosionAttackPlayer;
            int minValueExplosionAttackPlayer = 50;
            int maxValueExplosionAttackPlayer = 90;

            string userInput;

            int attacking;
            int enemy = 0;
            int player = 1;
            int attackPlayerAgain = 2;

            string textPlayer = "Твой ход";

            string textEnemy = "Ход босса";
            string textEnemyFight = "Босс наносит удар!";

            string wordStart = "Да";

            Console.WriteLine($"Добро пожаловать на бой с боссом, вы желаете начать? {wordStart}?\n" +
                "Иной выбор означает - нет.");
            userInput = Console.ReadLine();

            if (userInput == wordStart)
            {
                Console.WriteLine($"\nПриветствуем этого смельчака!\n" +
                    $"\nКаждый ход твоя мана растет на {recoveryMana} пункта.");
                attacking = player;
            }
            else
            {
                Console.WriteLine("Что? Нет!? Бой состоится в любом случае!\n");
                attacking = enemy;
            }

            while (healthEnemy > 0 && healthPlayer > 0)
            {
                attackEnemy = random.Next(minValueAttackEnemy, ++maxValueAttackEnemy);
                defaultAttackPlayer = random.Next(minValueDefaultAttackPlayer, ++maxValueDefaultAttackPlayer);
                fireballAttackPlayer = random.Next(minValueFireballAttackPlayer, ++maxValueFireballAttackPlayer);
                explosionAttackPlayer = random.Next(minValueExplosionAttackPlayer, ++maxValueExplosionAttackPlayer);

                Console.WriteLine($"Ваше здоровье: {healthPlayer}. Ваша мана: {manaPlayer}. " +
                    $"Количество колбочек лекарства: {amountHealing}\n" +
                    $"Здоровье босса: {healthEnemy}\n");

                if (attacking == player)
                {
                    Console.WriteLine(textPlayer);
                    Console.WriteLine($"{CommandDefaultAttackPlayer}) Обычный удар {defaultAttackPlayer} урона.\n" +
                        $"{CommandFireballAttackPlayer}) Огненный шар {fireballAttackPlayer} урона, " +
                        $"стоимость {manaPerFireball} маны.\n" +
                        $"{CommandExplosionAttackPlayer}) Взрыв {explosionAttackPlayer} урона, " +
                        $"стоимость {manaPerExplosion} маны.\n" +
                        $"{CommandHealingPlayer}) Восстановление {recoveryHealth} здоровья и {recoveryMana} маны.\n" +
                        $"Иной выбор - пропуск хода.\n" +
                        $"Введите один из пунктов + Enter.");
                    userInput = Console.ReadLine();

                    switch (userInput)
                    {
                        case CommandDefaultAttackPlayer:
                            healthEnemy -= defaultAttackPlayer;
                            healtEnemyAfterBlow = defaultAttackPlayer;
                            break;
                        case CommandFireballAttackPlayer:
                            if (manaPlayer >= manaPerFireball)
                            {
                                healthEnemy -= fireballAttackPlayer;
                                healtEnemyAfterBlow = fireballAttackPlayer;
                                counterFireball++;
                                manaPlayer -= manaPerFireball;
                            }
                            else
                            {
                                Console.WriteLine("\nУ вас недостаточно маны.\nEnter->");
                                Console.ReadKey();
                                Console.Clear();
                                attacking = attackPlayerAgain;
                            }
                            break;
                        case CommandExplosionAttackPlayer:
                            if (manaPlayer >= manaPerExplosion && counterFireball > 0)
                            {
                                healthEnemy -= explosionAttackPlayer;
                                healtEnemyAfterBlow = explosionAttackPlayer;
                                counterFireball--;
                                manaPlayer -= manaPerExplosion;
                            }
                            else
                            {
                                if (manaPlayer < manaPerExplosion && counterFireball == 0)
                                {
                                    Console.WriteLine("\nДля начала требуется накопить ману и использовать огненный шар" +
                                        ", а после только атаку - взрыв.\nEnter->");
                                    Console.ReadKey();
                                    Console.Clear();
                                    attacking = attackPlayerAgain;
                                }
                                else if (manaPlayer < manaPerExplosion)
                                {
                                    Console.WriteLine("\nУ вас недостаточно маны.\nEnter->");
                                    Console.ReadKey();
                                    Console.Clear();
                                    attacking = attackPlayerAgain;
                                }
                                else if (counterFireball == 0)
                                {
                                    Console.WriteLine("\nПрежде чем использовать взрывную атаку, " +
                                        "требуется атаковать огненным шаром\nEnter->");
                                    Console.ReadKey();
                                    Console.Clear();
                                    attacking = attackPlayerAgain;
                                }
                            }
                            break;
                        case CommandHealingPlayer:
                            if (amountHealing <= 0)
                            {
                                Console.WriteLine("У вас нехватает бутылочек с лекарством.");
                                Console.ReadKey();
                            }
                            else if (healthPlayer < maxHealthPlayer)
                            {
                                healthPlayer += recoveryHealth;
                                amountHealing -= amountAplicationsHealing;
                                if (healthPlayer > maxHealthPlayer)
                                {
                                    healthPlayer = maxHealthPlayer;
                                }
                            }
                            else if (healthPlayer == maxHealthPlayer)
                            {
                                Console.WriteLine("\nУ вас полный комплект здоровья.\nEnter->");
                                Console.ReadKey();
                            }
                            break;
                    }

                    if (userInput != CommandHealingPlayer)
                    {
                        Console.WriteLine($"\nВы нанесли боссу: {healtEnemyAfterBlow}.\nEnter->");
                        Console.ReadKey();
                    }
                }
                else
                {
                    if (userInput != CommandHealingPlayer)
                    {
                        Console.WriteLine($"{textEnemy}\n...\n{textEnemyFight}\nОн нанес {attackEnemy} урона.\nEnter->");
                        healthPlayer -= attackEnemy;
                        healtEnemyAfterBlow = 0;
                        Console.ReadKey();
                    }
                }

                if (manaPlayer < maxManaPlayer)
                {
                    manaPlayer += recoveryMana;
                    if (manaPlayer >= maxManaPlayer)
                    {
                        manaPlayer = maxManaPlayer;
                    }
                }

                if (attacking == attackPlayerAgain)
                {
                    attacking = player;
                }
                else if (attacking == player)
                {
                    attacking = enemy;
                }
                else
                {
                    attacking = player;
                }

                Console.Clear();
            }
            if (healthEnemy <= 0)
            {
                Console.Clear();
                Console.WriteLine("Победа!");
                Console.ReadKey();
            }
            else if (healthPlayer <= 0)
            {
                Console.Clear();
                Console.WriteLine("Ты проиграл, попробуй снова.");
                Console.ReadKey();
            }
            else if (healthPlayer <= 0 && healthEnemy <= 0)
            {
                Console.Clear();
                Console.WriteLine("Тьфу, это невозномжно, но это ничья!");
                Console.ReadKey();
            }
        }
    }
}