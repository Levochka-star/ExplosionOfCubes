﻿using System;

namespace HW_sequence
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int startNumber = 5;
            int endNumber = 103;
            int coefficientMagnification = 7;

            for (int i = startNumber; i <= endNumber; i += coefficientMagnification)
            {
                Console.WriteLine(i);
                Console.ReadKey();
            }
        }
    }
}
