﻿using System;
using System.Text;

namespace ДЗ_Кратные_числа
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.InputEncoding = Encoding.Unicode;
            Console.OutputEncoding = Encoding.Unicode;

            int startNumber = 50;
            int endNumber = 150;
            int coefficientMagnification;
            int sumNumbers = 0;

            Console.Write("Введите число \"N\" = (10 ≤ N ≤ 25)\n" +
                "\"N\" = ");
            coefficientMagnification = Convert.ToInt32(Console.ReadLine());

            for (int i = startNumber; i <= endNumber; i += coefficientMagnification)
            {
                sumNumbers += i;
            }

            Console.WriteLine($"Сумма чисел кратных {coefficientMagnification}, в промежутке " +
                $"от {startNumber} до {endNumber} равна {sumNumbers}");
            Console.ReadKey();
        }
    }
}
