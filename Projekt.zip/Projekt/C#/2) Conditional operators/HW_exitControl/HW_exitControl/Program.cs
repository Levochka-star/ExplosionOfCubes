﻿using System;

namespace HW_exitControl
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string userInput;
            string commandExit = "exit";

            Console.Write($"Введите {commandExit} для выхода: ");
            userInput = Console.ReadLine();

            while (userInput != commandExit)
            {
                Console.Write($"Введите по новой {commandExit} для выхода: ");
                userInput = Console.ReadLine();
            }
        }
    }
}