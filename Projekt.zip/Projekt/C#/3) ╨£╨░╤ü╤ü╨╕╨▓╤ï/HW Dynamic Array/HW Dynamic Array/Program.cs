﻿using System;

namespace HW_Dynamic_Array
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string CommandSum = "sum";
            const string CommandExit = "exit";

            int[] numbers = new int[0];
            int sumNumbers;
            string userInput;

            bool isOpen = true;

            while (isOpen)
            {

                if (numbers.Length != 0)
                {
                    for (int i = 0; i < numbers.Length; i++)
                    {
                        Console.Write(numbers[i] + " ");
                    }

                    Console.WriteLine();
                }

                Console.WriteLine($"Вы можете ввести: \"число\"\n" +
                    $"Команду \"{CommandSum}\".\n" +
                    $"Команду  \"{CommandExit}\", для выхода.\n");

                userInput = Console.ReadLine();

                switch (userInput)
                {
                    case CommandSum:
                        sumNumbers = 0;

                        for (int i = 0; i < numbers.Length; i++)
                        {
                            sumNumbers += numbers[i];
                        }

                        Console.WriteLine($"Сумма равна = {sumNumbers}");
                        Console.ReadKey();
                        break;

                    case CommandExit:
                        isOpen = false;
                        break;

                    default:
                        int[] tempNumbers = new int[numbers.Length + 1];

                        for (int i = 0; i < numbers.Length; i++)
                        {
                            tempNumbers[i] = numbers[i];
                        }

                        tempNumbers[tempNumbers.Length - 1] = Convert.ToInt32(userInput);
                        numbers = tempNumbers;
                        break;
                }

                Console.Clear();
            }
        }
    }
}