﻿using System;

namespace HW_Sorting_numbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int[] numbers = new int[10];
            int minValue = 0;
            int maxValue = 99;
            int counterLength = numbers.Length;
            int buffer;
            int maxElement;

            bool isOpen = true;

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = random.Next(minValue, maxValue + 1);
            }


            while (isOpen)
            {
                maxElement = int.MinValue;

                for (int i = 0; i < counterLength; i++)
                {
                    if (maxElement < numbers[i])
                    {
                        maxElement = numbers[i];
                    }
                }

                for (int i = 0; i < counterLength; i++)
                {
                    if (i < (counterLength - 1) && numbers[i] > numbers[i + 1])
                    {
                        buffer = numbers[i + 1];
                        numbers[i + 1] = numbers[i];
                        numbers[i] = buffer;

                    }

                    if (maxElement == numbers[counterLength - 1])
                    {
                        counterLength--;
                    }

                }

                if (counterLength == 0)
                {
                    isOpen = false;
                }
            }

            for (int i = 0; i < numbers.Length; i++)
            {
                Console.Write(numbers[i] + "  ");
            }

            Console.ReadKey();
        }
    }
}