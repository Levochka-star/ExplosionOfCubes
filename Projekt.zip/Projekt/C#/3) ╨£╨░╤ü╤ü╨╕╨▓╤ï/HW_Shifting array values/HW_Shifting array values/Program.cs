﻿using System;

namespace HW_Shifting_array_values
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[15];
            int counterShift;
            int buffer;

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = i + 1;
                Console.Write(numbers[i] + " ");
            }

            Console.WriteLine("\n");
            Console.Write("Введите на сколько единиц" +
                "надо сдвинуть массив: ");
            counterShift = Convert.ToInt32(Console.ReadLine());
            Console.Write("\n");

            counterShift = counterShift % numbers.Length;

            for (int i = 0; i < counterShift; i++)
            {
                for (int j = 0; j < numbers.Length - 1; j++)
                {
                    buffer = numbers[j];
                    numbers[j] = numbers[j + 1];
                    numbers[j + 1] = buffer;
                }
            }

            for (int i = 0; i < numbers.Length; i++)
            {
                Console.Write(numbers[i] + " ");
            }

            Console.ReadKey();
        }
    }
}