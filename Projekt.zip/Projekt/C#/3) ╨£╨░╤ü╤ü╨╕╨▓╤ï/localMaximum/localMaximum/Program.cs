﻿using System;

namespace localMaximum
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            int[] numbers = new int[30];

            int numberMinValue = 10;
            int numberMaxValue = 99;
            int extremeIndex = (numbers.Length - 1);

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = random.Next(numberMinValue, numberMaxValue + 1);
                Console.Write(numbers[i] + " ");
            }

            Console.SetCursorPosition(0, 2);

            if (numbers[0] > numbers[1])
            {
                Console.Write($"{numbers[0]} ");
            }
            else
            {
                Console.Write("__ ");
            }

            for (int i = 1; i < extremeIndex; i++)
            {
                if (numbers[i - 1] < numbers[i] && numbers[i] > numbers[i + 1])
                {
                    Console.Write($"{numbers[i]} ");
                }
                else
                {
                    Console.Write("__ ");
                }
            }

            if (numbers[extremeIndex - 1] < numbers[extremeIndex])
            {
                Console.Write($"{numbers[extremeIndex]}");
            }
            else
            {
                Console.Write("__");
            }

            Console.ReadKey();
        }
    }
}