﻿using System;

namespace HW_Split
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string offer = "Желание сменить работу светится в глазах";
            string[] words = offer.Split();

            foreach (string word in words)
            {
                Console.WriteLine(word);
            }

            Console.ReadKey();
        }
    }
}