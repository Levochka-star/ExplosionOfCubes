﻿using System;

namespace HW_Bracket_expression
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string brackerExpression = "(()()(())))";
            char[] brackers = new char [brackerExpression.Length];
            char brackerOpen = '(';
            int maxDepthBracker = int.MinValue;
            int counterDepthBracker = 0;

            for (int i = 0; i < brackers.Length; i++)
            {
                brackers[i] = brackerExpression[i];
                Console.Write(brackers[i]);
            }

            for (int i = 0; i < brackers.Length; i++)
            {
                if (brackers[i] == brackerOpen)
                {
                    counterDepthBracker++;
                }
                else
                {
                    counterDepthBracker--;
                }

                if (counterDepthBracker < 0)
                {
                    break;
                }

                if (maxDepthBracker < counterDepthBracker)
                {
                    maxDepthBracker = counterDepthBracker;
                }
            }

            if (maxDepthBracker > 0 && counterDepthBracker == 0)
            {
                Console.WriteLine($"\nстрока корректная и максимум глубины равняется {maxDepthBracker}");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine($"\nстрока некорректная");
                Console.ReadKey();
            }
        }
    }
}