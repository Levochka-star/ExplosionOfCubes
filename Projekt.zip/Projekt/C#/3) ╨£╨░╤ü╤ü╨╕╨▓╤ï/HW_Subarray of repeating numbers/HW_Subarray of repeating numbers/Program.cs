﻿using System;

namespace HW_Subarray_of_repeating_numbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int[] numbers = new int[30];

            int randomMinValue = 2;
            int randomMaxValue = 6;
            int counterNumbersInRow = 1;
            int maxCounterNumbersInRow = 0;
            int repeatNumber = 0;
            int maxRepeatNumber = 0;
            int lastIndex = numbers.Length - 1;

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = random.Next(randomMinValue, randomMaxValue + 1);
                Console.Write($"{numbers[i]} ");
            }

            for (int i = 0; i < lastIndex; i++)
            {
                if (numbers[i] == numbers[i + 1])
                {
                    counterNumbersInRow++;
                    repeatNumber = numbers[i];

                    if (maxCounterNumbersInRow < counterNumbersInRow && repeatNumber != 0)
                    {
                        maxCounterNumbersInRow = counterNumbersInRow;
                        maxRepeatNumber = repeatNumber;
                    }
                }
                else
                {
                    counterNumbersInRow = 1;
                }
            }

            Console.WriteLine($"\nчисло {maxRepeatNumber} повторяется {maxCounterNumbersInRow} раза подряд.");
            Console.ReadKey();
        }
    }
}