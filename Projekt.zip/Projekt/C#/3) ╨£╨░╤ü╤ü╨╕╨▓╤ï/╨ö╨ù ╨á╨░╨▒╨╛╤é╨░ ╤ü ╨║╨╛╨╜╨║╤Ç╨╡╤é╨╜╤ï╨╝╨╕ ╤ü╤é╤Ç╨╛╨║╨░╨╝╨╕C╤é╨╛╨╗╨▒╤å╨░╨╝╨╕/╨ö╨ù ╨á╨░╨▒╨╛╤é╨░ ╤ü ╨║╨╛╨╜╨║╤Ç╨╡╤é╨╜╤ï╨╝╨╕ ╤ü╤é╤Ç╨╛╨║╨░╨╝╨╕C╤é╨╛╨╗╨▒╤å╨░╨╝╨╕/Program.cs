﻿using System;

namespace HW_work_with_concrete_strange_columns
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] numbers =
            {
                { 4, 2, 3, 4 },
                { 2, 3, 4, 5 }
            };

            int arrayStringIndex = 1;
            int arrayColumnIndex = 0;

            int sumLine = 0;
            int multiplyRow = 1;

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    Console.Write(numbers[i, j] + " ");
                }

                Console.WriteLine();
            }

            for (int j = 0; j < numbers.GetLength(1); j++)
            {
                sumLine += numbers[arrayStringIndex, j];
            }

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                multiplyRow *= numbers[i, arrayColumnIndex];
            }

            Console.WriteLine($"\nСумма {arrayStringIndex + 1} строки равна" +
                $" {sumLine} и произведение {arrayColumnIndex + 1} столбца" +
                $" равно {multiplyRow}.");
            Console.ReadKey();
        }
    }
}