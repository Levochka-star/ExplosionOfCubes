﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_SwappingValues
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name = "Пушкин";
            string surename = "Александр";
            string buffer;

            Console.WriteLine($"Имя: {name}, а фамилия: {surename}");

            buffer = surename;
            surename = name;
            name = buffer;
            Console.WriteLine($"Имя: {name}, а фамилия: {surename}");


            string cupOne = "Кофе";
            string cupTwo = "Чай";
            Console.WriteLine($"В первой чашке: {cupOne}, а во второй: {cupTwo}");

            buffer = cupOne;
            cupOne = cupTwo;
            cupTwo = buffer;
            Console.WriteLine($"В первой чашке: {cupOne}, а во второй: {cupTwo}");

            Console.ReadKey();
        }
    }
}
