﻿using System;

namespace HW_Polyclinic
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Вы заходите в поликлинику и видите огромную очередь из пациентов, вы задумываетесь сколько вам ждать...");

            int numberPatients;
            int timeOnPatient = 10;
            int timeWaiting;
            int minutesPerHour = 60;
            int hourInLine;
            int minuteInLine;

            Console.Write("Введите количество пацаентов: ");
            numberPatients = Convert.ToInt32(Console.ReadLine());

            timeWaiting = numberPatients * timeOnPatient;
            hourInLine = timeWaiting / minutesPerHour;
            minuteInLine = timeWaiting % minutesPerHour;

            Console.WriteLine($"Вы должны отстоять в очереди {hourInLine} часа и {minuteInLine} минут.");
            Console.ReadKey();
        }
    }
}