﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_CrystalStore
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Вы хотите обменять золото на кристаллы");
            Console.ReadKey();
            Console.WriteLine("Добро пожаловать в магазин кристаллов!");
            Console.ReadKey();

            int userGold;
            int userRestGold;
            int crystalPrice = 35;
            int userCrystal;

            Console.WriteLine($"Цена кристаллов {crystalPrice}");
            Console.Write("Введите имеющееся количество золота: ");

            userGold = Convert.ToInt32(Console.ReadLine());
            userCrystal = userGold / crystalPrice;
            userRestGold = userGold % crystalPrice;

            Console.WriteLine($"У вас {userRestGold} золота и {userCrystal} кристаллов");
            Console.ReadKey();

            /////////////////////////////////////////////////////////////////////////////////////////////////////////

            Console.WriteLine();
            Console.WriteLine();

            /////////////////////////////////////////////////////////////////////////////////////////////////////////

            Console.WriteLine("Вы снова хотите объменять кристаллы?");
            Console.WriteLine("Добро пожаловать в магазин кристаллов!");

            Console.WriteLine($"Цена кристаллов {crystalPrice}");
            Console.Write("Введите имеющееся количество золота: ");

            userGold = Convert.ToInt32(Console.ReadLine());
            userCrystal = userGold / crystalPrice;
            userRestGold = userGold % crystalPrice;

            Console.WriteLine($"У вас {userRestGold} золота и {userCrystal} кристаллов");
            Console.ReadKey();

            /////////////////////////////////////////////////////////////////////////////////////////////////////////

            Console.WriteLine();
            Console.WriteLine();

            /////////////////////////////////////////////////////////////////////////////////////////////////////////

            Console.WriteLine("Добро пожаловать в улучшенный магазин кристаллов!");

            //int userGold;
            //int crystalPrice = 35;
            int wantCrystal;
            bool comparison;
            int userCrysral;
            
            Console.WriteLine($"Цена кристаллов {crystalPrice}");
            Console.Write("Введите имеющееся количество золота: ");
            userGold = Convert.ToInt32(Console.ReadLine());
            Console.Write("Сколько желаете приобрести кристаллов? - ");
            wantCrystal = Convert.ToInt32(Console.ReadLine());

            comparison = userGold >= wantCrystal * crystalPrice;
            wantCrystal *= Convert.ToInt32(comparison);
            userCrysral = wantCrystal * crystalPrice;
            userGold -= userCrysral;

            Console.WriteLine($"Остаток золота: {userGold}, куплены кристаллы: {wantCrystal}");
            Console.ReadKey();

            /////////////////////////////////////////////////////////////////////////////////////////////////////////

            Console.WriteLine();
            Console.WriteLine();

            /////////////////////////////////////////////////////////////////////////////////////////////////////////
            
            Console.WriteLine("Вы снова хотите объменять кристаллы?");
            Console.WriteLine("Добро пожаловать в тот же улучшенный магазин кристаллов!");

            Console.WriteLine($"Цена кристаллов {crystalPrice}");
            Console.Write("Введите имеющееся количество золота: ");
            userGold = Convert.ToInt32(Console.ReadLine());
            Console.Write("Сколько желаете приобрести кристаллов? - ");
            wantCrystal = Convert.ToInt32(Console.ReadLine());

            comparison = userGold >= wantCrystal * crystalPrice;
            wantCrystal *= Convert.ToInt32(comparison);
            userCrysral = wantCrystal * crystalPrice;
            userGold -= userCrysral;

            Console.WriteLine($"Остаток золота: {userGold}, куплены кристаллы: {wantCrystal}");
            Console.ReadKey();

            ///////////////////////////////////////////////////////////////////////////////////////
            ///
            ///ИТОГОВЫЙ ВАРИАНТ, ПРИНЯТЫЙ МЕНТОРОМ
            Console.WriteLine();
            Console.WriteLine();
            ///
            ///////////////////////////////////////////////////////////////////////////////////////

            Console.WriteLine("Добро пожаловать в магазин кристаллов! ИТОГОВЫЙ ВАРИАНТ, ПРИНЯТЫЙ МЕНТОРОМ и доработанный мной");

            int amountCrystals;
            bool canBuyCrystal;

            Console.WriteLine($"Цена кристаллов {crystalPrice}");
            Console.Write("Введите имеющееся количество золота: ");
            userGold = Convert.ToInt32(Console.ReadLine());
            Console.Write("Сколько желаете приобрести кристаллов? - ");
            amountCrystals = Convert.ToInt32(Console.ReadLine());

            canBuyCrystal = userGold >= amountCrystals * crystalPrice;
            amountCrystals *= Convert.ToInt32(canBuyCrystal);
            userGold -= amountCrystals * crystalPrice;

            Console.WriteLine($"Остаток золота: {userGold}, куплены кристаллы: {amountCrystals}");
            Console.ReadKey();

        }
    }
}
