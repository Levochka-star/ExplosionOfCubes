﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_workingWithStrings
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.InputEncoding = Encoding.Unicode;
            Console.OutputEncoding = Encoding.Unicode;

            string userName;
            string birthday;
            string job;
            string car;
            string salary;
            string dream;

            Console.Write("Введите ваше имя: ");
            userName = Console.ReadLine(); 
            Console.Write("Когда вы появилсь не свет?(Датой) - ");
            birthday = Console.ReadLine(); 
            Console.Write("Желаемая работа: я хочу работать ");
            job = Console.ReadLine(); 
            Console.Write("Машину какой марки вы хотели бы? - ");
            car = Console.ReadLine();
            Console.Write("Желаемый общий заработок (введите число, без валюты): ");
            salary = Console.ReadLine();
            Console.Write("О чем вы мечтаете? - о ");
            dream = Console.ReadLine();

            Console.WriteLine($"Тебя зовут {userName} и ты родился/(ась): {birthday}, это прекрасная дата.");
            Console.WriteLine($"Ты хочешь работать {job} ведь ты желаешь себе машину марки {car},");
            Console.WriteLine($"для этого тебе нужно зарабатывать {salary} рублей.");
            Console.WriteLine($"Ты мечтаешь о {dream} и у тебя действительно всё получится)");

            Console.WriteLine("Это я написал)");

            Console.ReadKey();
        }
    }
}