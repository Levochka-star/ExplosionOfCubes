﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_variables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            byte symbols = 4;
            short age = 20;
            string script = "Скрипт";
            float results = 5.7f;
            char name = 't';
            // Не придумал ничего лучше чем узнать жив ли персонаж
            //Сравнив значения переменных health и damage
            float health = 100;
            int damage = 5;
            bool isThePlayerAlive = health > damage;

            long length = 5000;
            sbyte blocsInMinecraft = 127;
        }
    }
}
