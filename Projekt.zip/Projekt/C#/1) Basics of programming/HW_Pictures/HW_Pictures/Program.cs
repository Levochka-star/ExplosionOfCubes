﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_Pictures
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int allPicturesInAlbum = 52;
            int picturesInRow = 3;
            int rows;
            int remainderDivision;

            rows = allPicturesInAlbum / picturesInRow;
            remainderDivision = allPicturesInAlbum % picturesInRow;

            Console.WriteLine($"Полностью заполненных рядов {rows}, и картин сверх меры {remainderDivision}.");
            Console.ReadKey();
        }
    }
}
