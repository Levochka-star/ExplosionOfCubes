﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Сложности_понимания_С___1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Вход в приложение

            Console.WriteLine("Программа показывает как происходит КОНКАТЕНАЦИЯ и ИНТЕРПОЛЯЦИЯ.");
            Console.WriteLine("Удачи это понять новичку, такому как я.");
            Console.WriteLine();

            int number = 10;

            Console.WriteLine(5 + number + " " + "Не равно" +
                " " + 5 + number + ", " + number + 5 + ", " +
                "НО равно" + " " + (number + 5) + " " +
                "и равно" + " " + (5 + number));

            Console.WriteLine($"{5 + number} Не равно 5{number}, " +
                $"{number}5, НО равно {number + 5} и равно {5 + number}");

            Console.ReadKey();
        }
    }
}
