﻿using System;

namespace Kansas_City_Shuffle
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            int[] numbers = new int[10];

            int maxValue = numbers.Length;

            FillArray(numbers);

            ShowNumbers(numbers);

            Console.WriteLine();

            Shuffle(numbers, random);

            ShowNumbers(numbers);

            Console.ReadKey();
        }

        static void ShowNumbers(int[] numbers)
        {
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.Write($"{numbers[i]} ");
            }
        }

        static void Shuffle(int[] array, Random random)
        {
            int bufferNumber;

            for (int i = 0; i < array.Length; i++)
            {
                int randomIndex = random.Next(array.Length);

                if (randomIndex != i)
                {
                    bufferNumber = array[i];
                    array[i] = array[randomIndex];
                    array[randomIndex] = bufferNumber;
                }
            }
        }

        static void FillArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = i + 1;
            }
        }
    }
}