﻿using System;

namespace ReadInt
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int outputNumber;
            outputNumber = ReadInt();
            Console.Write("Ваше число: " + outputNumber);
            Console.ReadKey();
        }

        private static int ReadInt()
        {
            bool isOpen = true;
            string inputNumber;
            int results = 0;

            while (isOpen)
            {
                Console.Clear();
                Console.Write($"Введите число: ");
                inputNumber = Console.ReadLine();

                if (int.TryParse(inputNumber, out int number))
                {
                    results = number;
                    isOpen = false;
                }
                else
                {
                    Console.Write($"Попробуйте снова! Нажмите любую клавишу");
                    Console.ReadKey();
                }
            }

            return results;
        }
    }
}