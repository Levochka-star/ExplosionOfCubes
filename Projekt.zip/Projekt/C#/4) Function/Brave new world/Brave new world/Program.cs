﻿using System;

namespace Brave_new_world
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;

            int playerPositionX = 8;
            int playerPositionY = 15;

            int stringInfoPositionX = 10;
            int stringInfoDollarsX = 5;
            int indentInfoFromMap = 18;
            int stringInfoPositionY;
            int valueDollars = 0;
            int valueScoreDollars = 0;
            int valueDollarsOnGameMap = 0;

            char player = '@';
            char dollars = '$';
            char wall = '#';
            char spase = ' ';

            bool isOpen = true;

            char[,] gameMap = new char[,]
            {
                {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'},
                {'#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', '$', '#', '$', '#'},
                {'#', ' ', '#', '#', '#', '#', '#', '#', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', ' ', '#', ' ', '#'},
                {'#', ' ', '#', ' ', ' ', ' ', ' ', '$', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', ' ', '#', ' ', '#'},
                {'#', ' ', '#', ' ', '#', '#', '#', ' ', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', ' ', ' ', ' ', '#'},
                {'#', ' ', '#', ' ', '#', '$', '#', ' ', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', '#', '#'},
                {'#', '$', '#', ' ', '#', '$', '#', ' ', '#', ' ', ' ', ' ', ' ', ' ', '#', '#', '#', '#', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', ' ', ' ', '$', '#'},
                {'#', ' ', '#', ' ', '#', '$', '#', ' ', '#', ' ', ' ', ' ', ' ', ' ', '#', ' ', ' ', ' ', '#', ' ', ' ', ' ', ' ', '#', '#', '#', '#', '#', '#', '#', '#', '#'},
                {'#', ' ', '#', ' ', '#', '$', '#', ' ', '#', ' ', ' ', ' ', ' ', ' ', '#', ' ', '#', ' ', '#', ' ', ' ', ' ', ' ', '#', ' ', ' ', ' ', '#', '$', ' ', '#', '#'},
                {'#', ' ', '#', ' ', ' ', ' ', '#', ' ', '#', ' ', ' ', ' ', ' ', ' ', ' ', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', ' ', ' ', ' ', ' ', '$', '#'},
                {'#', ' ', '#', '#', '#', '#', '#', ' ', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', '#', '#', '#', '#', '#', ' ', '$', '#'},
                {'#', ' ', ' ', ' ', ' ', ' ', '$', ' ', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', '$', ' ', '$', '#', '$', ' ', '#', '#'},
                {'#', '#', '#', '#', '#', '#', '#', '#', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', '#', '#', ' ', '#', '#', '#', '#', '#'},
                {'#', ' ', ' ', ' ', '#', ' ', '$', ' ', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', ' ', ' ', ' ', ' ', ' ', '#'},
                {'#', ' ', '#', '$', '#', ' ', '#', ' ', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', ' ', '#', ' ', ' ', ' ', ' ', '$', '#'},
                {'#', ' ', '#', ' ', '#', ' ', '#', ' ', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', ' ', '#', '#', '#', '#', '#', ' ', '#'},
                {'#', '$', '#', ' ', ' ', '$', '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#', '$', ' ', ' ', ' ', '$', ' ', ' ', '#'},
                {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'},
            };

            stringInfoPositionY = GetIndent(gameMap, stringInfoPositionX, indentInfoFromMap);

            Console.SetCursorPosition(stringInfoPositionY, stringInfoPositionX);
            Console.WriteLine("(Ходить на стрелки)");

            ConsoleColor defoultLetter = Console.ForegroundColor;

            valueDollarsOnGameMap = GetSumValueMoney(valueDollarsOnGameMap, gameMap, dollars);

            while (isOpen)
            {
                Console.SetCursorPosition(0, 0);
                DrawMap(gameMap, spase, dollars, wall);

                Console.ForegroundColor = ConsoleColor.DarkCyan;

                Console.SetCursorPosition(playerPositionY, playerPositionX);

                Console.Write(player);

                Console.ForegroundColor = defoultLetter;

                stringInfoPositionY = GetIndent(gameMap, stringInfoDollarsX, indentInfoFromMap);

                DrawRetrievedDollars(valueScoreDollars, defoultLetter, stringInfoPositionY, stringInfoDollarsX);

                ConsoleKeyInfo pressKey = Console.ReadKey();

                MovePlauerIndex(pressKey, ref playerPositionX, ref playerPositionY, gameMap, spase, dollars);

                valueDollars = GetSumValueMoney(valueDollars, gameMap, dollars);

                valueScoreDollars = valueDollarsOnGameMap - valueDollars;

                if (valueScoreDollars == valueDollarsOnGameMap)
                {
                    isOpen = false;
                }
            }

            Console.Clear();

            Console.Write("Вы прошли игру! Нажмите любую клавишу");
            Console.ReadKey();
        }

        static int GetIndent(char[,] map, int indentX, int indentInfoFromMap)
        {
            int maxValue = int.MinValue;
            int result = 100;

            for (int i = 0; i < map.GetLength(0); i++)
            {
                for (int j = 0; j < map.GetLength(1); j++)
                {
                    if (maxValue < j)
                    {
                        maxValue = j;
                    }

                    if (i == indentX && j == maxValue)
                    {
                        result = j + indentInfoFromMap;
                    }
                }
            }

            return result;
        }

        static void DrawRetrievedDollars(int valueDollars, ConsoleColor defoultLetter, int stringInfoPositionY, int stringInfoDollarsX)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;

            Console.SetCursorPosition(stringInfoPositionY, stringInfoDollarsX);
            Console.WriteLine($"Вы нашли {valueDollars} долларов!");

            Console.ForegroundColor = defoultLetter;
        }

        static int GetSumValueMoney(int valueDollarsOnGameMap, char[,] gameMap, char dollars)
        {
            valueDollarsOnGameMap = 0;

            for (int i = 0; i < gameMap.GetLength(0); i++)
            {
                for (int j = 0; j < gameMap.GetLength(1); j++)
                {
                    if (gameMap[i, j] == dollars)
                    {
                        valueDollarsOnGameMap++;
                    }
                }
            }

            return valueDollarsOnGameMap;
        }

        static void DrawMap(char[,] map, char spase, char dollars, char wall)
        {
            ConsoleColor defoult = Console.ForegroundColor;

            for (int i = 0; i < map.GetLength(0); i++)
            {
                for (int j = 0; j < map.GetLength(1); j++)
                {
                    if (map[i, j] == wall)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                        Console.Write(map[i, j]);
                    }
                    else if (map[i, j] == spase)
                    {
                        Console.ForegroundColor = defoult;
                        Console.Write(map[i, j]);
                    }
                    else if (map[i, j] == dollars)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write(map[i, j]);
                    }
                }

                Console.ForegroundColor = defoult;
                Console.WriteLine();
            }
        }

        static void MovePlauerIndex(ConsoleKeyInfo pressedKey, ref int playerPositionX, ref int playerPositionY, char[,] map, char spase, char dollar)
        {
            int[] direction = GetDirection(pressedKey);

            int nextPlayerPositionX = playerPositionX + direction[1];
            int nextPlayerPositionY = playerPositionY + direction[0];

            if (map[nextPlayerPositionX, nextPlayerPositionY] == spase)
            {
                playerPositionX = nextPlayerPositionX;
                playerPositionY = nextPlayerPositionY;
            }
            
            if (map[nextPlayerPositionX, nextPlayerPositionY] == dollar)
            {
                map[nextPlayerPositionX, nextPlayerPositionY] = spase;

                playerPositionX = nextPlayerPositionX;
                playerPositionY = nextPlayerPositionY;
            }
        }

        static int[] GetDirection(ConsoleKeyInfo pressedKey)
        {
            ConsoleKey moveUp = ConsoleKey.UpArrow;
            ConsoleKey moveDown = ConsoleKey.DownArrow;
            ConsoleKey moveLeft = ConsoleKey.LeftArrow;
            ConsoleKey moveRight = ConsoleKey.RightArrow;

            int[] direction = { 0, 0 };

            if (pressedKey.Key == moveUp)
            {
                direction[1] = -1;
            }
            else if (pressedKey.Key == moveDown)
            {
                direction[1] = 1;
            }
            else if (pressedKey.Key == moveLeft)
            {
                direction[0] = -1;
            }
            else if (pressedKey.Key == moveRight)
            {
                direction[0] = 1;
            }

            return direction;
        }
    }
}