﻿using System;

namespace Personnel_accounting
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string CommandAddDossier = "1";
            const string CommandDrawFullDossier = "2";
            const string CommandDeleteDossier = "3";
            const string CommandSearchSecondName = "4";
            const string CommandExit = "5";

            string[] fullNames = new string[0];
            string[] positions = new string[0];

            string searchDossier = "";
            string inputMenuItem;

            int numberDossier = 0;
            int lengthArray = fullNames.Length;

            bool isOpenProgramm = true;

            while (isOpenProgramm)
            {
                Console.Clear();

                DrawMenuDossier(CommandAddDossier, CommandDrawFullDossier, CommandDeleteDossier, CommandSearchSecondName, CommandExit);

                inputMenuItem = Console.ReadLine();

                switch (inputMenuItem)
                {
                    case CommandAddDossier:
                        AddDossier(ref fullNames, ref positions);
                        break;

                    case CommandDrawFullDossier:
                        ShowDossiers(fullNames, positions);
                        break;

                    case CommandDeleteDossier:
                        DeleteDossier(ref fullNames, ref positions, numberDossier);
                        break;

                    case CommandSearchSecondName:
                        SearchSecondName(fullNames, positions, searchDossier);
                        break;

                    case CommandExit:
                        isOpenProgramm = false;
                        break;
                }
            }
        }

        static void DrawMenuDossier(string сommandAddDossier, string сommandFillDossier, string сommandDeleteDossier, string сommandSearchDossier, string CommandExit)
        {
            Console.WriteLine($"{сommandAddDossier}) Добавить досье");
            Console.WriteLine($"{сommandFillDossier}) Показать все досье");
            Console.WriteLine($"{сommandDeleteDossier}) Удалить досье");
            Console.WriteLine($"{сommandSearchDossier}) Найти по фамилии");
            Console.WriteLine($"{CommandExit}) Выход");

            Console.Write("\nВведите пункт меню + Enter: ");
        }

        static void AddDossier(ref string[] personName, ref string[] positionPerson)
        {
            string inputUser;

            Console.Write("Введите ФИО человека: ");
            inputUser = Console.ReadLine();

            personName = IncreaseArray(personName, inputUser);

            Console.Write("Введите должность человека: ");
            inputUser = Console.ReadLine();

            positionPerson = IncreaseArray(positionPerson, inputUser);
        }

        static string[] IncreaseArray(string[] array, string inputUser)
        {
            string[] tempArray = new string[array.Length + 1];

            for (int i = 0; i < array.Length; i++)
            {
                tempArray[i] = array[i];
            }

            tempArray[array.Length] = inputUser;

            return tempArray;
        }

        static void ShowDossiers(string[] personName, string[] positionPerson)
        {
            if (HaveElements(personName) != false)
            {
                DrawDossier(personName, positionPerson);
                ReadKey();
            }
        }

        static void DrawDossier(string[] personName, string[] positionPerson)
        {
            int lastIndex = personName.Length;
            int numberDossier = 0;

            for (int i = 0; i < personName.Length; i++)
            {
                numberDossier++;

                if (i < lastIndex)
                {
                    Console.Write($"{numberDossier}) ");
                }

                Console.Write(personName[i]);

                if (i < lastIndex)
                {
                    Console.Write(" - ");
                }

                Console.Write(positionPerson[i] + ' ');
            }
        }

        static void DeleteDossier(ref string[] personNames, ref string[] positionPersons, int numberDossier)
        {
            if (HaveElements(personNames) != false)
            {
                DrawDossier(personNames, positionPersons);

                Console.Write("\nВведите номер досье: ");

                numberDossier = GetNumber();

                if (numberDossier > personNames.Length || numberDossier < 1)
                {
                    Console.WriteLine("\nВы ввели неверное число");

                    ReadKey();
                }
                else
                {
                    personNames = DeleteIndexArray(personNames, numberDossier);
                    positionPersons = DeleteIndexArray(positionPersons, numberDossier);
                }
            }
        }

        static string[] DeleteIndexArray(string[] arrayDossier, int inputNumber)
        {
            string[] tempDossier = new string[arrayDossier.Length - 1];

            int numberIndex = inputNumber - 1;

            for (int i = 0; i < numberIndex; i++)
            {
                tempDossier[i] = arrayDossier[i];
            }

            for (int i = numberIndex + 1; i < tempDossier.Length + 1; i++)
            {
                tempDossier[i - 1] = arrayDossier[i];
            }

            return tempDossier;
        }

        static void SearchSecondName(string[] personName, string[] positionPerson, string searchDossier)
        {
            int numberDossier = 0;

            if (HaveElements(personName) != false)
            {
                Console.Write($"Введите фамилию: ");
                searchDossier = Console.ReadLine();

                for (int i = 0; i < personName.Length; i++)
                {
                    string[] secondNames = personName[i].Split();

                    foreach (string secondName in secondNames)
                    {
                        if (secondName == searchDossier)
                        {
                            numberDossier++;

                            Console.Write(numberDossier + ") ");
                            Console.Write($"{personName[i]} - {positionPerson[i]} ");
                        }
                    }
                }

                if (numberDossier == 0)
                {
                    Console.WriteLine("\nТаких досье не найдено!");
                }
            
                ReadKey();
            }
        }

        static bool HaveElements(string[] array)
        {
            bool error = true;

            if (array.Length < 1)
            {
                error = false;

                Console.WriteLine("\nНет ни одного досье!");

                ReadKey();
            }

            return error;
        }

        static int GetNumber()
        {
            bool isOpen = true;
            int number;
            int result = 0;

            while (isOpen)
            {
                string inputNumber = Console.ReadLine();

                if (int.TryParse(inputNumber, out number))
                {
                    result = number;
                    isOpen = false;
                }
                else
                {
                    Console.Write("Указано не число, попробуйте снова: ");
                }
            }

            return result;
        }

        static void ReadKey()
        {
            Console.Write("\nНажмите любую клавишу");
            Console.ReadKey();
        }
    }
}