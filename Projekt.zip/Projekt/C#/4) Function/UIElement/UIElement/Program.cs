﻿using System;

namespace UIElement
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int length = 10;
            int persentHealth;
            int persentMana;
            int minUserInput = 0;
            int maxUserInput = 100;

            Console.WriteLine("Сколько здоровья у персонажа? (в процентах)");
            persentHealth = GetNumber(minUserInput, maxUserInput);
            DrawBar(persentHealth, ConsoleColor.Green, length);

            Console.WriteLine("Сколько маны у персонажа? (в процентах)");
            persentMana = GetNumber(minUserInput, maxUserInput);
            DrawBar(persentMana, ConsoleColor.DarkBlue, length);

            Console.ReadKey();
        }

        static int GetFullLength(int inputLength, int inputUser)
        {
            float length = Convert.ToSingle(inputLength);
            float onePersent;
            float result;

            int persent = 100;
            int valueCell;

            onePersent = length / persent;
            result = inputUser * onePersent;

            valueCell = Convert.ToInt32(result);

            return valueCell;
        }

        static int GetNumber(int minValueInput, int maxValueInput)
        {
            bool isOpen = true;
            int number;
            int result = 0;

            while (isOpen)
            {
                string inputNumber = Console.ReadLine();

                if (int.TryParse(inputNumber, out number))
                {
                    result = number;

                    if (result > maxValueInput || result < minValueInput)
                    {
                        Console.Write("Указаное число не подходит, попробуйте снова: ");
                    }
                    else
                    {
                        isOpen = false;
                    }
                }
                else
                {
                    Console.Write("Указано не число, попробуйте снова: ");
                }
            }

            return result;
        }

        static void DrawBar(int value, ConsoleColor color, int length)
        {
            string cell = "#";
            string spase = "_";
            string bar = "";

            int fullLength = GetFullLength(length, value);
            int lengthSpases = length - fullLength;

            ConsoleColor colorCell = color;
            ConsoleColor defaultColor = Console.ForegroundColor;

            Console.Write("[");

            Console.ForegroundColor = colorCell;
            bar = FillBar(cell, fullLength);
            Console.Write(bar);

            Console.ForegroundColor = defaultColor;
            bar = FillBar(spase, lengthSpases);
            Console.Write(bar);
            Console.Write("]");
            Console.WriteLine();
        }

        static string FillBar(string symbol, int quantity)
        {
            string bar = "";

            for (int i = 0; i < quantity; i++)
            {
                bar += symbol;
            }

            return bar;
        }
    }
}