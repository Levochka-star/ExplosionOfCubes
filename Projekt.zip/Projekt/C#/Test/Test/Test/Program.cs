﻿using System;

namespace HW_Element_width
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int[,] numbers = new int[10, 10];
            int maxElement = int.MinValue;
            int minValueRandom = 1;
            int maxValueRandom = 10;
            int replacementOfValue = 0;

            Console.SetCursorPosition(0, 2);
            Console.WriteLine("Матрица до изменений:");

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    numbers[i, j] = random.Next(minValueRandom, maxValueRandom);
                    Console.Write(numbers[i, j] + " ");

                    if (maxElement < numbers[i, j])
                    {
                        maxElement = numbers[i, j];
                    }
                }

                Console.WriteLine();
            }

            Console.SetCursorPosition(0, 14);
            Console.WriteLine("Матрица после изменений:");

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    if (numbers[i, j] == maxElement)
                    {
                        numbers[i, j] = replacementOfValue;
                    }

                    Console.Write(numbers[i, j] + " ");
                }

                Console.WriteLine();
            }

            Console.SetCursorPosition(0, 0);
            Console.WriteLine($"Максимальный элемент матрицы: {maxElement}");
            Console.ReadKey();
        }
    }
}