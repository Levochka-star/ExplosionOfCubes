﻿using System;
using System.Collections.Generic;

namespace War
{
    internal class Program
    {
        static void Main(string[] args)
        {
            War wars = new War();
            wars.Work();
        }
    }

    public interface IDamageable
    {
        void TakeDamage(int damage);
    }

    class War
    {
        private SoldersFactory _soldersFactory = new SoldersFactory();
        private Platoon _platoon1;
        private Platoon _platoon2;

        public War()
        {
            _platoon1 = new Platoon(_soldersFactory);
            _platoon2 = new Platoon(_soldersFactory);


        }

        public void Work()
        {
            List<IDamageable> soldiers1 = _platoon1.CopySolders();
            List<IDamageable> soldiers2 = _platoon2.CopySolders();

            Console.WriteLine("Здесь пройдет баталия!");
            Console.WriteLine();
            Console.ReadKey();

            while (_platoon1.CanFight() && _platoon2.CanFight())
            {
                Console.Clear();

                _platoon1.ShowInfoSquad("Первый");
                _platoon2.ShowInfoSquad("Второй");

                _platoon1.Attack(soldiers2);
                _platoon2.RemoveDeadSoldiers();

                _platoon2.Attack(soldiers1);
                _platoon1.RemoveDeadSoldiers();

                Console.ReadKey();
            }

            Console.Clear();
            ShowInfoWinner();
            Console.ReadKey();
        }

        public void ShowInfoWinner()
        {
            if (_platoon1.SquadCount == _platoon2.SquadCount)
            {
                Console.WriteLine("Обоюдное поражение");
            }
            else if (_platoon1.SquadCount < _platoon2.SquadCount)
            {
                Console.WriteLine("Победил второй взвод");
            }
            else if (_platoon1.SquadCount > _platoon2.SquadCount)
            {
                Console.WriteLine("Победил первый взвод");
            }
        }
    }

    class Platoon 
    {
        private List<Soldier> _soldiers = new List<Soldier>();

        public Platoon(SoldersFactory soldersFactory)
        {
            _soldiers = soldersFactory.CreateSoldiers();
        }

        public int SquadCount => _soldiers.Count;

        public List<IDamageable> CopySolders()
        {
            return new List<IDamageable>(_soldiers);
        }

        public void ShowInfoSquad(string nameSquad)
        {
            Console.WriteLine($"{nameSquad} взвод:\n");
            
            for (int i = 0; i < _soldiers.Count; i++)
            {
                if (_soldiers[i].Health > 0)
                {
                    Console.WriteLine($"{_soldiers[i].Name} здоровье: {_soldiers[i].Health}");
                }
            }

            Console.WriteLine();
        }

        public void RemoveDeadSoldiers()
        {
            for (int i = _soldiers.Count - 1; i >= 0; i--)
            {
                if (_soldiers[i].Health <= 0)
                {
                    _soldiers.RemoveAt(i);
                }
            }
        }

        public void Attack(List<IDamageable> enemies)
        {
            for (int i = 0; i < _soldiers.Count; i++)
            {
                _soldiers[i].Attack(enemies);
            }
        }

        public bool CanFight()
        {
            bool isFightPossible = false;

            for (int i = 0; i < _soldiers.Count; i++)
            {
                if (_soldiers[i].Health > 0)
                {
                    isFightPossible = true;
                }
            }

            return isFightPossible;
        }
    }

    class SoldersFactory
    {
        public List<Soldier> CreateSoldiers()
        {
            return new List<Soldier>()
            {
              new Grunt("Пехотинец", 300, 15),
              new Grunt("Пехотинец", 300, 15),
              new Grunt("Пехотинец", 300, 15),
              new Sniper("Снайпер", 350, 40),
              new Minesweeper("Минёр", 300, 10),
              new Grenadier("Гранатометчик", 200, 30),
              new Grenadier("Гранатометчик", 200, 30)
            };
        }
    }

    class Soldier : IDamageable
    {
        protected int Damage;

        public Soldier(string name, int health, int damage)
        {
            Name = name;
            Health = health;
            Damage = damage;
        }

        public int Health { get; private set; }
        public string Name { get; private set; }

        public virtual void Attack(List<IDamageable> damagebles)
        {
            damagebles[Utils.GenerateRandomPositiveIndex(damagebles.Count)].TakeDamage(Damage);
        }

        public void TakeDamage(int damage)
        {
            Health -= damage;
        }
    }

    class Grunt : Soldier
    {
        public Grunt(string name, int health, int damage) : base(name, health, damage) { }
    }

    class Sniper : Soldier
    {
        private int _damageMultiplier = 3;

        public Sniper(string name, int health, int damage) : base(name, health, damage) { }

        public override void Attack(List<IDamageable> damagebles)
        {
            damagebles[Utils.GenerateRandomPositiveIndex(damagebles.Count)].TakeDamage(Damage * _damageMultiplier);
        }
    }

    class Minesweeper : Soldier
    {
        public Minesweeper(string name, int health, int damage) : base(name, health, damage) { }

        public override void Attack(List<IDamageable> damagebles)
        {
            int attacksCount = Utils.GenerateRandomPositiveIndex(damagebles.Count);

            List<IDamageable> attackedEnemies = new List<IDamageable>(damagebles);

            for (int i = 0; i < attacksCount; i++)
            {
                int indexEnemy = (Utils.GenerateRandomPositiveIndex(attackedEnemies.Count));
                attackedEnemies[indexEnemy].TakeDamage(Damage);
                attackedEnemies.RemoveAt(indexEnemy);
            }
        }
    }

    class Grenadier : Soldier
    {
        public Grenadier(string name, int health, int damage) : base(name, health, damage) { }

        public override void Attack(List<IDamageable> damagebles)
        {
            int valueNumberAttacks = Utils.GenerateRandomPositiveIndex(damagebles.Count);

            for (int i = 0; i < valueNumberAttacks; i++)
            {
                damagebles[Utils.GenerateRandomPositiveIndex(damagebles.Count)].TakeDamage(Damage);
            }
        }
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static int GenerateRandomPositiveIndex(int maxIndex)
        {
            return s_random.Next(maxIndex);
        }
    }
}