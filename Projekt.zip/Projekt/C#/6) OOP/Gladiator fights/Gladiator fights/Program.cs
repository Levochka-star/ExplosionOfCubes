﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Gladiator_fights
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Arena arena = new Arena();

            arena.Work();
        }
    }

    class Arena
    {
        private List<Warrior> _warriors = new List<Warrior>();

        public Arena()
        {
            _warriors.Add(new Bandit("Бандит", 120, 10));
            _warriors.Add(new Hunter("Охотник", 95, 13));
            _warriors.Add(new Goblin("Гоблин", 74, 12, 10));
            _warriors.Add(new Wizard("Волшебник", 90, 15, 20, 10));
            _warriors.Add(new Thief("Вор", 70, 14));
        }

        public void Work()
        {
            const int CommandWelcomeMessage = 1;
            const int CommandShowBattle = 2;
            const int CommandExit = 3;

            bool isWork = true;

            ShowIntro();

            while (isWork)
            {
                ShowMenu(CommandWelcomeMessage, CommandShowBattle, CommandExit);

                switch (Utils.ReadInt())
                {
                    case CommandWelcomeMessage:
                        ShowIntro();
                        break;

                    case CommandShowBattle:
                        Battle();
                        break;

                    case CommandExit:
                        isWork = false;
                        break;

                    default:
                        InputInvalid();
                        break;
                }

                Console.Clear();
            }
        }

        private void Battle()
        {
            SelectWarriors(out Warrior warrior1, out Warrior warrior2);

            Console.WriteLine("В бой!\n");
            Fight(warrior1, warrior2);

            Console.WriteLine();
            DetermineWinner(warrior1, warrior2);
        }

        private void DetermineWinner(Warrior warrior1, Warrior warrior2)
        {
            if (warrior1.Health == warrior2.Health)
            {
                Console.WriteLine("Ничья");
            }
            else if (warrior1.Health <= warrior2.Health)
            {
                Console.WriteLine($"Победил игрок {warrior2.Name}");
            }
            else if (warrior2.Health <= warrior1.Health)
            {
                Console.WriteLine($"Победил игрок {warrior1.Name}");
            }

            Console.ReadKey();
        }

        private void Fight(Warrior warrior1, Warrior warrior2)
        {
            string warrior1Name = warrior1.Name;
            string warrior2Name = warrior2.Name;

            while (warrior1.Health > 0 && warrior2.Health > 0)
            {
                Console.WriteLine($"{warrior2Name} атакует {warrior1Name}а.");
                warrior2.Attack(warrior1);
                Console.WriteLine($"Здоровье бойца {warrior1Name}: {warrior1.Health}\n");

                Console.WriteLine($"{warrior1Name} атакует {warrior2Name}а. ");
                warrior1.Attack(warrior2);
                Console.WriteLine($"Здоровье бойца {warrior2Name}: {warrior2.Health}\n");

                Thread.Sleep(800);
            }
        }

        private void SelectWarriors(out Warrior warrior1, out Warrior warrior2)
        {
            Console.Clear();
            ShowDefaultListWarrior();

            warrior1 = ChooseWarrior(1);
            warrior2 = ChooseWarrior(2);

            ShowPlayerSelectedWarriors(warrior1.Name, warrior2.Name);
        }

        private Warrior ChooseWarrior(int numberWarrior)
        {
            Console.WriteLine($"\nВыберите {numberWarrior}-го война для боя:");
            int indexInput = (Utils.GetNumberPositiveInRange(_warriors.Count) - 1);
            
            return _warriors[indexInput].Clone();
        }

        private void ShowPlayerSelectedWarriors(string warrior1, string warrior2)
        {
            Console.Clear();
            Console.WriteLine("Выбранные войны:\n");
            Console.WriteLine($"1) {warrior1}\n2) {warrior2}\n");
            Console.ReadKey();
        }

        private void ShowDefaultListWarrior()
        {
            for (int i = 0; i < _warriors.Count; i++)
            {
                int numberWarrior = i + 1;
                Console.WriteLine($"{numberWarrior}) {_warriors[i].Name}");
            }
        }

        private void ShowMenu(int commandWelcomeMessage, int commandShowBattle, int commandExit)
        {
            Console.WriteLine($"{commandWelcomeMessage}. Приветственное сообщение.\n" +
                                $"{commandShowBattle}. Посмотреть бой.\n" +
                                $"{commandExit}. Выход из программы.\n");
        }

        private void InputInvalid()
        {
            Console.WriteLine("Такого пункта нет! Читай внимательнее!");
            Console.ReadKey();
        }

        private void ShowIntro()
        {
            Console.Clear();
            Console.WriteLine("Приветствую вас на арене колизея!" +
                "\nВыберите двух бойцов и смотрите за происходящим!");
            Console.ReadKey();
            Console.Clear();
        }
    }

    class Warrior
    {
        protected Warrior(string name, int health, int damage)
        {
            Name = name;
            Health = health;
            Damage = damage;
        }

        public string Name { get; private set; }
        public int Health { get; protected set; }
        public int Damage { get; private set; }

        public virtual void TakeDamage(int damage)
        {
            Health -= damage;
        }

        public virtual void Attack(Warrior enemy)
        {
            enemy.TakeDamage(Damage);
        }

        public virtual Warrior Clone()
        {
            return new Warrior(Name, Health, Damage);
        }
    }

    class Bandit : Warrior
    {
        private int _doubleDamageChance = 30;

        public Bandit(string name, int health, int damage) : base(name, health, damage) { }

        public override void Attack(Warrior enemy)
        {
            int currentDamage = Damage;
            int damageCoeficient = 2;
            bool hasDoubleDamage = false;

            if (Utils.RollChance(_doubleDamageChance))
            {
                currentDamage *= damageCoeficient;
                hasDoubleDamage = true;
            }

            if (hasDoubleDamage)
            {
                Console.WriteLine($"{enemy.Name} получает {damageCoeficient}-ой урон ({currentDamage})");
            }
            else
            {
                Console.WriteLine($"{enemy.Name} получает урон ({Damage})");
            }

            enemy.TakeDamage(currentDamage);
        }

        public override Warrior Clone()
        {
            return new Bandit(Name, Health, Damage);
        }
    }

    class Hunter : Warrior
    {
        private int _attackCount;
        private int _numberEnhancedAttack = 3;

        public Hunter(string name, int health, int damage) : base(name, health, damage) { }

        public override void Attack(Warrior enemy)
        {
            int currentDamage = Damage;
            bool hasDoubleDamage = false;

            _attackCount++;

            if (_attackCount == _numberEnhancedAttack)
            {
                hasDoubleDamage = true;
                _attackCount = 0;
            }

            Console.WriteLine($"{enemy.Name} получает урон ({Damage})");
            enemy.TakeDamage(Damage);

            if (hasDoubleDamage)
            {
                Console.WriteLine($"{enemy.Name} получает урон от повторной атаки ({Damage})");
                enemy.TakeDamage(Damage);
            }
        }

        public override Warrior Clone()
        {
            return new Hunter(Name, Health, Damage);
        }
    }

    class Goblin : Warrior
    {
        private int _pointsRage;
        private int _maxPointsRage;
        private int _increasedAngry = 6;
        private int _increasedHealth = 11;

        public Goblin(string name, int health, int damage, int maxAngry) : base(name, health, damage)
        {
            _maxPointsRage = maxAngry;
        }

        public override void Attack(Warrior enemy)
        {
            int currentDamage = Damage;
            bool hasHealing = false;

            _pointsRage += _increasedAngry;

            if (_pointsRage >= _maxPointsRage)
            {
                _pointsRage -= _maxPointsRage;
                Health += _increasedHealth;
                hasHealing = true;
            }

            if (hasHealing)
            {
                Console.Write($"А сам использует лечение (здоровье + {_increasedHealth} ");
            }

            Console.WriteLine($"{enemy.Name} получает урон ({currentDamage})");

            enemy.TakeDamage(currentDamage);
        }

        public override Warrior Clone()
        {
            return new Goblin(Name, Health, Damage, _maxPointsRage);
        }
    }

    class Wizard : Warrior
    {
        private int _mana;
        private int _maxMana;
        private int _increasedMana = 6;
        private int _fireballDamage;

        public Wizard(string name, int health, int damage, int fireballDamage, int maxMana) : base(name, health, damage)
        {
            _maxMana = maxMana;
            _fireballDamage = fireballDamage;
        }

        public override void Attack(Warrior enemy)
        {
            int currentDamage = Damage;
            bool hasMaxMana = false;

            _mana += _increasedMana;

            if (_mana >= _maxMana)
            {
                currentDamage = _fireballDamage;
                _mana -= _maxMana;
                hasMaxMana = true;
            }

            if (hasMaxMana)
            {
                Console.WriteLine($"{enemy.Name} получает огненным шаром. Нанесён урон ({currentDamage})");
            }
            else
            {
                Console.WriteLine($"{enemy.Name} получает урон ({currentDamage})");
            }

            enemy.TakeDamage(currentDamage);
        }

        public override Warrior Clone()
        {
            return new Wizard(Name, Health, Damage, _fireballDamage, _maxMana);
        }
    }

    class Thief : Warrior
    {
        private int _dodgeChance = 40;

        public Thief(string name, int health, int damage) : base(name, health, damage) { }

        public override void Attack(Warrior enemy)
        {
            Console.WriteLine($"{enemy.Name} получает урон ({Damage})");

            enemy.TakeDamage(Damage);
        }

        public override void TakeDamage(int damage)
        {
            if (Utils.RollChance(_dodgeChance))
            {
                Console.WriteLine($"{Name} уворачивается от урона!");
            }
            else
            {
                base.TakeDamage(damage);
            }
        }

        public override Warrior Clone()
        {
            return new Thief(Name, Health, Damage);
        }
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static bool RollChance(int chance)
        {
            int max = 100;

            return GenerateRandomNumber(max) <= chance;
        }

        public static int GenerateRandomNumber(int maxNumber)
        {
            return s_random.Next(maxNumber + 1);
        }

        public static int ReadInt()
        {
            bool isOpen = true;
            string inputNumber;
            int results = 0;

            while (isOpen)
            {
                Console.Write($"Введите число: ");
                inputNumber = Console.ReadLine();

                if (int.TryParse(inputNumber, out int number))
                {
                    results = number;
                    isOpen = false;
                }
                else
                {
                    Console.WriteLine($"Попробуйте снова! Нажмите любую клавишу");
                    Console.ReadKey();
                }
            }

            return results;
        }

        public static int GetNumberPositiveInRange(int maxNumber)
        {
            bool isOpen = true;
            string inputUser;
            int result = 0;

            while (isOpen)
            {
                inputUser = Console.ReadLine();

                if (int.TryParse(inputUser, out result) && result > 0 && result <= maxNumber)
                {
                    isOpen = false;
                }
                else
                {
                    Console.Write("\nТакого нет.\nПопробуй ввести сейчас: ");
                }
            }

            return result;
        }
    }
}