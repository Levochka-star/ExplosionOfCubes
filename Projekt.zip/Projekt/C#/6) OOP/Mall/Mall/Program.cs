﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Mall
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Mall mall = new Mall();

            mall.Work();
        }
    }

    class Mall
    {
        public void Work()
        {
            Seller seller = new Seller();
            Buyer buyer = new Buyer();

            List<Product> productsSeller = new List<Product>();
            List<Product> productsBuyer = new List<Product>();

            productsSeller = seller.GetListProducts();
            productsBuyer = buyer.GetListProducts();

            while (seller.GetProductsCount() > 0 && buyer.IsPossibleToBuy(buyer.Money, productsSeller))
            {
                Console.Clear();
                seller.ShowBalance(seller.Money, "продавца");
                buyer.ShowBalance(buyer.Money, "покупателя");
                Console.WriteLine();

                seller.ShowListIsntEmpty(productsSeller, "продавца");
                Console.WriteLine();
                buyer.ShowListIsntEmpty(productsBuyer, "покупателя");
                Console.WriteLine();

                Console.WriteLine($"Покупатель выбирает из списка...");
                int userInput = buyer.GetInputUser(seller.GetProductsCount());
                Console.WriteLine($"\nПокупатель выбрал товар с номером - {userInput}\n");

                if (buyer.Money >= productsSeller[userInput - 1].Price)
                {
                    int priceProduct = productsSeller[userInput - 1].Price;

                    productsBuyer.Add(productsSeller[userInput - 1]);
                    buyer.RemoveMoney(priceProduct);
                    productsSeller.RemoveAt(userInput - 1);
                    seller.AddMoney(priceProduct);
                }
                else
                {
                    Console.ReadKey();
                    Console.WriteLine($"Покупатель не может себе это позволить...");
                }

                Console.ReadKey();
            }

            Console.Clear();
            seller.ShowBalance(seller.Money, "продавца");
            buyer.ShowBalance(buyer.Money, "покупателя");

            Console.WriteLine();
            seller.ShowListIsntEmpty(productsSeller, "продавца");
            Console.WriteLine();
            buyer.ShowListIsntEmpty(productsBuyer, "покупателя");

            Console.ReadKey();
        }
    }

    class Product
    {
        public Product(string name, int price)
        {
            Name = name;
            Price = price;
        }

        public int Price { get; private set; }
        public string Name { get; private set; }
    }

    class Human
    {
        protected List<Product> Products = new List<Product>();

        protected Human(int money)
        {
            Money = money;
        }

        public int Money { get; protected set; }

        public List<Product> GetListProducts()
        {
            List<Product> products = new List<Product>();

            for (int i = 0; i < GetProductsCount(); i++)
            {
                products.Add(GetProductByIndex(i));
            }

            return products;
        }

        public void ShowLots(string nameRoleHuman, List<Product> products)
        {
            Console.WriteLine($"Продукты {nameRoleHuman}: ");

            for (int i = 0; i < products.Count; i++)
            {
                Console.WriteLine($"{i + 1}) {products[i].Name} {products[i].Price}руб.");
            }
        }

        public void ShowBalance(int money, string nameRole)
        {
            Console.WriteLine($"Деньги {nameRole}: {money} руб.");
        }

        public void ShowListIsntEmpty(List<Product> products, string humanRole)
        {
            if (products.Count != 0)
            {
                ShowLots(humanRole, products);
            }
        }

        public int GetProductsCount()
        {
            return Products.Count;
        }

        private Product GetProductByIndex(int indexProduct)
        {
            return Products.ElementAt(indexProduct);
        }
    }

    class Seller : Human
    {
        public Seller() : base(0)
        {
            CreateProducts();
        }

        public void AddMoney(int money)
        {
            Money += money;
        }

        private void CreateProducts()
        {
            Products.Add(new Product("Стул", 3899));
            Products.Add(new Product("Стол", 8699));
            Products.Add(new Product("Роутер", 3600));
            Products.Add(new Product("Часы", 10999));
            Products.Add(new Product("Шлем", 30899));
            Products.Add(new Product("Подушка", 1699));
            Products.Add(new Product("Жига", 80899));
            Products.Add(new Product("Кальян", 8699));
        }
    }

    class Buyer : Human
    {
        public Buyer() : base(60000) { }

        public int GetInputUser(int productsCount)
        {
            Console.Write("\nВыберите продукт: ");
            return Utils.GetNumberFromZeroInRange(productsCount);
        }

        public void RemoveMoney(int money)
        {
            Money -= money;
        }

        public bool IsPossibleToBuy(int money, List<Product> products)
        {
            bool isPossible = false;

            for (int i = 0; i < products.Count; i++)
            {
                if (money >= products[i].Price)
                {
                    isPossible = true;
                }
            }

            return isPossible;
        }
    }

    class Utils
    {
        public static int GetNumberFromZeroInRange(int maxNumberMenu)
        {
            bool isOpen = true;
            string inputUser;
            int result = 0;

            while (isOpen)
            {
                inputUser = Console.ReadLine();

                if (int.TryParse(inputUser, out result) && result > 0 && result <= maxNumberMenu)
                {
                    isOpen = false;
                }
                else
                {
                    Console.Write("\nТакого нет.\nПопробуй ввести сейчас: ");
                }
            }

            return result;
        }
    }
}