﻿using System;
using System.Collections.Generic;

namespace CarService
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DetailsFactory detailsFactory = new DetailsFactory();
            CarService carService = new CarService(detailsFactory);

            carService.Work(detailsFactory);
        }
    }

    class CarService
    {
        private CarsFactory _carsFactory = new CarsFactory();
        private Warehouse _warehouse;
        private Queue<Car> _cars;

        private int _penalty = 1500;
        private int _money = 5000;

        public CarService(DetailsFactory detailsFactory)
        {
            _warehouse = new Warehouse(detailsFactory);
            _cars = new Queue<Car>(_carsFactory.GenerateQueue(detailsFactory));
        }

        public int RepairPrice => 3000;

        public void Work(DetailsFactory detailsFactory)
        {
            const string CommandFailureRepair = "отказ от детали";
            const string CommandFailureAllRepair = "отказ в ремонте";
            const string CommandExit = "выход";

            bool isWork = true;
            int minValueCars = 5;

            Car car = null;

            while (isWork)
            {
                if (_cars.Count < minValueCars)
                {
                    _cars = new Queue<Car>(_carsFactory.GenerateQueue(detailsFactory));
                }

                if (car == null)
                {
                    car = _cars.Dequeue();
                }

                ShowMenu(car, CommandFailureRepair, CommandFailureAllRepair, CommandExit);

                string inputUser = Console.ReadLine();

                switch (inputUser)
                {
                    case CommandFailureRepair:
                        FailureOneRepair(ref car);
                        break;

                    case CommandFailureAllRepair:
                        FailureAllRepair(ref car);
                        break;

                    case CommandExit:
                        isWork = false;
                        break;

                    default:
                        TryRepair(car, inputUser);
                        break;
                }

                if (car == null)
                {
                    Console.Clear();
                    Console.WriteLine("Вы видите следующего клиента..");
                    Console.ReadKey();
                }
                else if (car.HasBrokenDetails() == false)
                {
                    Console.Clear();
                    car.ShowInfoDetails();
                    car = null;
                    Console.WriteLine("Машина исправна!");
                    Console.ReadKey();
                }
            }
        }

        public void Repair(Detail detail, Car car)
        {
            if (detail.IsWorkable == false && _warehouse.TrySearchDetail(detail, out Detail newDetail))
            {
                _money += (newDetail.Cost + RepairPrice);

                Console.WriteLine("Удачный ремонт!");
                car.Paste(newDetail);
            }
            else if (detail.IsWorkable != false)
            {
                Console.WriteLine("Вы выбрали исправную деталь!");
                ShowInfoOfPenalty(detail, car);
            }
            else if (_warehouse.TrySearchDetail(detail, out newDetail) == false)
            {
                Console.WriteLine("Вы выбрали деталь которой нет на складе!");
                ShowInfoOfPenalty(detail, car);
            }

            Console.ReadKey();
        }

        private void ShowInfoOfPenalty(Detail detail, Car car)
        {
            Console.WriteLine("Платите штраф за неверную команду!");

            _money -= _penalty;
            car.Paste(detail);
        }

        private void ShowMenu(Car car, string commandFailureRepair, string commandFailureAllRepair, string commandExit)
        {
            Console.Clear();

            Console.WriteLine($"У вас клиент. Цена замены одной детали:{RepairPrice}руб.\n");

            car.ShowInfoDetails();

            Console.WriteLine("\nДетали на складе:");

            _warehouse.ShowInfoWarehouse();  

            Console.WriteLine($"\nВаш счет: {_money}руб. Штраф за отказ от ремонта детали: {_penalty}руб.");
            Console.WriteLine("\nВпишите номер детали или наберите команду." +
                $"\nВведите \"{commandFailureRepair}\" для отказа в ремонте детали" +
                $"\nВведите \"{commandFailureAllRepair}\" для отказа в ремонте машины" +
                $"\nВведите \"{commandExit}\" для выхода");
        }

        private void TryRepair(Car car, string inputUser)
        {
            if (int.TryParse(inputUser, out int number))
            {
                Repair(car.CutDetail(Utils.GetNumberPositiveInRange(number, car.DetailsCount)), car);
            }
            else
            {
                Console.WriteLine("Вы ошиблись с вводом!");
                Console.ReadKey();
            }
        }

        private void FailureOneRepair(ref Car car)
        {
            string inputUser;

            Console.Clear();
            car.ShowInfoDetails();
            Console.WriteLine("\nВы отказали в ремонте детали, выберите деталь и получите штраф!");

            inputUser = Console.ReadLine();
            Detail detail = car.CutDetail(Utils.GetNumberPositiveInRange(inputUser, car.DetailsCount));

            if (detail.IsWorkable == false)
            {
                Console.WriteLine($"\nШтраф за отказ от ремонта детали: {_penalty} руб.\nСумма штрафа составит: {_penalty} руб.");

                _money -= _penalty;
            }
            else
            {
                int penalty = 2000;
                Console.WriteLine($"\nШтраф за отказ от ремонта ИСПРАВНОЙ детали: {penalty} руб.\nКлиент посчитал вас" +
                    $" дилетантом\nСумма штрафа составит: {penalty} руб.");

                car.Paste(detail);
                _money -= penalty;
            }

            Console.ReadKey();
        }

        private void FailureAllRepair(ref Car car)
        {
            Console.Clear();
            car.ShowInfoDetails();
            Console.WriteLine("Вы отказали в ремонте!");
           
            int valueBrokenDetails = car.SumBrokenDetails();
            int penalty = _penalty * valueBrokenDetails;

            Console.WriteLine($"\nШтраф за отказ от ремонта детали: {_penalty} руб.\nДеталей неотремонтировано:" +
                $" {valueBrokenDetails}\nСумма штрафа составит: {penalty} руб.");

            car = null;
            _money -= penalty;
            Console.ReadKey();
        }
    }

    class Warehouse
    {
        private List<Detail> _details = new List<Detail>();

        public Warehouse(DetailsFactory detailsFactory)
        {
            _details.AddRange(detailsFactory.GenerateList());
        }

        public void ShowInfoWarehouse()
        {
            string currency = "руб";

            int valueGenerator = 0;
            int generatorCost = 0;
            int valueEngine = 0;
            int engineCost = 0;
            int valueInjector = 0;
            int injectorCost = 0;

            for (int i = 0; i < _details.Count; i++)
            {
                if (_details[i].Name == "Генератор")
                {
                    valueGenerator++;
                    generatorCost = _details[i].Cost;
                }
                else if (_details[i].Name == "Двигатель")
                {
                    valueEngine++;
                    engineCost = _details[i].Cost;
                }
                else if (_details[i].Name == "Инжектор")
                {
                    valueInjector++;
                    injectorCost = _details[i].Cost;
                }
            }

            Console.WriteLine($"Двигатель - {valueEngine} шт, ценa одной: {engineCost}{currency}.");
            Console.WriteLine($"Генератор - {valueGenerator} шт, ценa одной: {generatorCost}{currency}.");
            Console.WriteLine($"Инжектор - {valueInjector} шт, ценa одной: {injectorCost}{currency}.");
        }

        public bool TrySearchDetail(Detail detail, out Detail newDetail)
        {
            bool hasDetail = false;
            newDetail = null;

            for (int i = 0; i < _details.Count; i++)
            {
                if (_details[i].Name == detail.Name)
                {
                    hasDetail = true;
                    newDetail = _details[i];

                    _details.RemoveAt(i);
                    break;
                }
            }

            return hasDetail;
        }
    }

    class Car
    {
        private List<Detail> _details = new List<Detail>();

        public Car(List<Detail> details)
        {
            _details = details;
        }

        public int DetailsCount => _details.Count;

        public void ShowInfoDetails()
        {
            for (int i = 0; i < _details.Count; i++)
            {
                string isWorkable = _details[i].IsWorkable == false ? "поломан" : "исправен";
                int numberPointMenu = i + 1;
                Console.WriteLine($"{numberPointMenu}) {_details[i].Name} - {isWorkable}");
            }
        }

        public Detail CutDetail(int numberDetail)
        {
            Detail detail = _details[numberDetail - 1];
            _details.RemoveAt(numberDetail - 1);
            return detail;
        }

        public void Paste(Detail detail)
        {
            _details.Add(detail);
        }

        public int SumBrokenDetails()
        {
            int brokenDetails = 0;

            for (int i = 0; i < DetailsCount; i++)
            {
                if (_details[i].IsWorkable == false)
                {
                    brokenDetails++;
                }
            }
            return brokenDetails;
        }

        public bool HasBrokenDetails()
        {
            bool hasBrokenDetails = false;

            for (int i = 0; i < DetailsCount; i++)
            {
                if (_details[i].IsWorkable == false)
                {
                    hasBrokenDetails = true;
                }
            }

            return hasBrokenDetails;
        }
    }

    class CarsFactory
    {
        public Queue<Car> GenerateQueue(DetailsFactory detailsFactory)
        {
            Queue<Car> cars = new Queue<Car>();
            List<Detail> details = new List<Detail>();

            int maxValueCars = 6;
            int maxValueDatailsOneType = 1;

            for (int i = 0; i < maxValueCars; i++)
            {
                bool isWork = true;

                while (isWork)
                {
                    details.Clear();

                    details = detailsFactory.GenerateList(maxValueDatailsOneType);

                    for (int j = 0; j < details.Count; j++)
                    {
                        Detail detail = new Detail(details[j].Name, details[j].Cost, BreakingDetail());

                        details.RemoveAt(j);
                        details.Add(detail);

                        if (details[j].IsWorkable == false)
                        {
                            isWork = false;
                        }
                    }
                }

                cars.Enqueue(new Car(new List<Detail>(details)));
            }

            return cars;
        }

        private bool BreakingDetail()
        {
            bool[] isWorkable = new bool[] { false, true };

            return isWorkable[Utils.GenerateNumberInRange(isWorkable.Length)];
        }
    }

    class Detail
    {
        public Detail(string name, int cost, bool isWorkable)
        {
            Name = name;
            Cost = cost;
            IsWorkable = isWorkable;
        }

        public bool IsWorkable { get; private set; }
        public string Name { get; private set; }
        public int Cost { get; private set; }
    }

    class DetailsFactory
    {
        public List<Detail> GenerateList(int maxValueDatailsOneType = 40)
        {

            List<Detail> details = new List<Detail>();

            details.AddRange(FillList("Генератор", 5000, true, maxValueDatailsOneType));
            details.AddRange(FillList("Двигатель", 30000, true, maxValueDatailsOneType));
            details.AddRange(FillList("Инжектор", 7000, true, maxValueDatailsOneType));

            return details;
        }

        private List<Detail> FillList(string name, int cost, bool isWorkable, int valueDetails)
        {
            List<Detail> details = new List<Detail>();

            for (int i = 0; i < valueDetails; i++)
            {
                details.Add(new Detail(name, cost, isWorkable));
            }

            return details;
        }
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static int GenerateNumberInRange(int maxNumber)
        {
            return s_random.Next(maxNumber++);
        }

        public static int GetNumberPositiveInRange(string inputUser, int maxNumber)
        {
            bool isOpen = true;
            int result = 0;

            while (isOpen)
            {
                if (int.TryParse(inputUser, out result) && result > 0 && result <= maxNumber)
                {
                    isOpen = false;
                }
                else
                {
                    Console.Write("\nОшибка, такого числа нет.\nПопробуй ввести что-то другое:");
                    inputUser = Console.ReadLine();
                }
            }

            return result;
        }

        public static int GetNumberPositiveInRange(int inputUser, int maxNumber)
        {
            bool isOpen = true;
            int result = 0;

            while (isOpen)
            {
                if (inputUser > 0 && inputUser <= maxNumber)
                {
                    isOpen = false;
                    result = inputUser;
                }
                else
                {
                    Console.Write("\nОшибка, такого числа нет.\nПопробуй ввести что-то другое:");
                    inputUser = GetNumberPositiveInRange(Console.ReadLine(), maxNumber);
                }
            }

            return result;
        }
    }
}