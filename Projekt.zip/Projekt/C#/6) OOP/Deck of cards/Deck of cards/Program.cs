﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Deck_of_cards
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.InputEncoding = Encoding.Unicode;
            Console.OutputEncoding = Encoding.Unicode;

            Croupier croupier = new Croupier();
            Player player = new Player();

            croupier.PassCards(player);
            player.ShowCards();

            Console.ReadKey();
        }
    }

    class Player
    {
        private List<Card> _cards = new List<Card>();

        public void ShowCards()
        {
            for (int i = 0; i < _cards.Count; i++)
            {
                ConsoleColor deafaultColor = Console.ForegroundColor;

                Console.ForegroundColor = _cards[i].Color;
                Console.Write($"{_cards[i].Suit}{_cards[i].Value}");
                Console.ForegroundColor = deafaultColor;

                if (_cards.Count - 1 != i)
                {
                    Console.Write(", ");
                }
            }
        }

        public void AddCard(Card card)
        {
            _cards.Add(card);
        }
    }

    class Croupier
    {
        private PackCard _packCard = new PackCard();

        public void PassCards(Player player)
        {
            int valueCards;

            Console.WriteLine($"Сколько карт требуется игроку?");
            valueCards = Utils.GetPositiveNumber();
            Console.WriteLine();

            if (_packCard.HasCardsCount(valueCards))
            {
                for (int i = 0; i < valueCards; i++)
                {
                    player.AddCard(_packCard.GiveCard());
                }
            }
            else
            {
                Console.WriteLine("Ошибка количества");
            }
        }
    }

    class Card
    {
        public Card(string suit, string value, ConsoleColor color)
        {
            Suit = suit;
            Value = value;
            Color = color;
        }

        public string Suit { get; private set; }
        public string Value { get; private set; }
        public ConsoleColor Color { get; private set; }
    }

    class PackCard
    {
        private List<Card> _cards = new List<Card>();

        public PackCard()
        {
            string[] redSuits = new string[] { "♥", "♦" };
            string[] blackSuits = new string[] { "♠", "♣" };
            string[] valueCards = new string[] { "6", "7", "8", "9", "10", "J", "D", "K", "T" };

            CreateCard(redSuits, blackSuits, valueCards);
        }

        public Card GiveCard()
        {
            int indexCard = Utils.GetRandomNumber(0, _cards.Count);

            Card card = _cards[indexCard];
            _cards.RemoveAt(indexCard);
            return card;
        }

        public bool HasCardsCount(int userInput)
        {
            return _cards.Count >= userInput;
        }

        private void CreateCard(string[] redSuits, string[] blackSuits, string[] valueCards)
        {
            for (int i = 0; i < redSuits.Length; i++)
            {
                for (int j = 0; j < valueCards.Length; j++)
                {
                    _cards.Add(new Card(redSuits[i], valueCards[j], ConsoleColor.DarkRed));
                }
            }

            for (int i = 0; i < blackSuits.Length; i++)
            {
                for (int j = 0; j < valueCards.Length; j++)
                {
                    _cards.Add(new Card(blackSuits[i], valueCards[j], ConsoleColor.DarkCyan));
                }
            }
        }
    }

    class Utils
    {
        private static Random _random = new Random();

        public static int GetRandomNumber(int minValue, int maxValue)
        {
            return _random.Next(minValue, maxValue);
        }

        public static int GetPositiveNumber()
        {
            string userInput;
            int result = 0;
            bool isOpen = true;

            while (isOpen)
            {
                userInput = Console.ReadLine();

                if (int.TryParse(userInput, out result) && result > 0)
                {
                    isOpen = false;
                }
                else
                {
                    Console.Write("\nОшибка, это не число.\nВводите по новой: ");
                }
            }

            return result;
        }
    }
}