﻿using System;

namespace Work_with_classes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string namePlayer;

            int healthPlayer;
            int manaPlayer;
            int moneyPlayer;

            Utils.GetInfoForPlayer(out namePlayer, out healthPlayer, out manaPlayer, out moneyPlayer);

            Player farmer = new Player(namePlayer, healthPlayer, manaPlayer, moneyPlayer);

            farmer.ShowState();

            Console.ReadKey();
        }
    }

    class Player
    {
        private string _name;

        private int _health;
        private int _mana;
        private int _money;

        public Player (string name, int helth, int mana, int money)
        {
            _name = name;
            _health = helth;
            _mana = mana;
            _money = money;
        }

        public void ShowState()
        {
            Console.WriteLine($"\n Игрок {_name}\nЗдоровье: {_health}\nМана: {_mana}\nДеньги: {_money}");
        }
    }

    class Utils
    {
        public static void GetInfoForPlayer(out string namePlayer, out int healthPlayer, out int manaPlayer, out int moneyPlayer)
        {
            Console.Write("Введите имя у персонажа: ");
            namePlayer = Console.ReadLine();

            Console.Write("Введите здоровье у персонажа: ");
            healthPlayer = ReadInt();

            Console.Write("Введите ману у персонажа: ");
            manaPlayer = ReadInt();

            Console.Write("Введите количество золотых у персонажа: ");
            moneyPlayer = ReadInt();
        }

        public static int ReadInt()
        {
            bool isOpen = true;

            string userInput;

            int result = -1;

            while (isOpen)
            {
                userInput = Console.ReadLine();

                if (int.TryParse(userInput, out int number))
                {
                    result = number;
                    isOpen = false;
                }
                else
                {
                    Console.WriteLine("Это не число, попробуй снова");
                }
            }

            return result;
        }
    }
}