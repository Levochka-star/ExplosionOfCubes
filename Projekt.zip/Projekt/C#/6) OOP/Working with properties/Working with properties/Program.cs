﻿using System;

namespace Working_with_properties
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Player dog = new Player(2, 3);
            Renderer sketch = new Renderer();

            sketch.ShowPlayer(dog);
            Console.ReadKey();
        }
    }

    class Player
    {
        public Player(int xСoordinate, int yСoordinate, char symbol = '@')
        {
            Symbol = symbol;
            YСoordinate = xСoordinate;
            XСoordinate = yСoordinate;
        }

        public char Symbol { get ; private set; }
        public int XСoordinate { get; private set; }
        public int YСoordinate { get; private set; }
    }

    class Renderer
    {
        public void ShowPlayer (Player player)
        {
            Console.SetCursorPosition (player.XСoordinate, player.YСoordinate);
            Console.WriteLine(player.Symbol);
        }
    }
}
