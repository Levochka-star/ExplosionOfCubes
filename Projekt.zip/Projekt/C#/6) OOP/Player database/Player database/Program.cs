﻿using System;
using System.Collections.Generic;

namespace Player_database
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int CommandAddPlayer = 1;
            const int CommandBanPlayer = 2;
            const int CommandUnbanPlayer = 3;
            const int CommandRemovePlayer = 4;
            const int CommandExit = 5;

            Database basePlayers = new Database();

            int minValueMenu = CommandAddPlayer;
            int maxValueMenu = CommandExit;

            bool isOpen = true;

            while (isOpen)
            {
                Console.CursorVisible = false;
                Console.Clear();
                Utils.DrawMenu(CommandAddPlayer, CommandBanPlayer, CommandUnbanPlayer, CommandRemovePlayer, CommandExit);

                Console.SetCursorPosition(0, 0);
                basePlayers.DrawBase();

                switch (Utils.GetNumber(minValueMenu, maxValueMenu))
                {
                    case CommandAddPlayer:
                        basePlayers.AddPerson();
                        break;

                    case CommandBanPlayer:
                        basePlayers.BanPerson();
                        break;

                    case CommandUnbanPlayer:
                        basePlayers.UnbanPerson();
                        break;

                    case CommandRemovePlayer:
                        basePlayers.DeletePerson();
                        break;

                    case CommandExit:
                        isOpen = false;
                        break;
                }
            }
        }
    }

    class Player
    {
        public Player(int numberPlayer, string namePlayer, int level, bool isBanned = false)
        {
            Id = numberPlayer;
            Name = namePlayer;
            Level = level;
            IsBanned = isBanned;
        }

        public int Id { get; private set; }
        public string Name { get; private set; }
        public int Level { get; private set; }
        public bool IsBanned { get; private set; }

        public void BanAndUndbandle(bool isBan)
        {
            IsBanned = isBan;
        }
    }

    class Database
    {
        private int _index;

        private List<Player> _listGamers = new List<Player>();

        public void AddPerson()
        {
            Console.Clear();

            string name;
            int level;

            _index = Utils.GetUniqueNumber(_index);

            Console.Write("Введите ник игрока: ");
            name = Utils.GetNamePerson();

            Console.Write("Введите уровень игрока: ");
            level = Utils.ReadInt();

            _listGamers.Add(new Player(_index, name, level));

            Console.WriteLine("\nИгрок добавлен успешно!");
            Console.ReadKey();
        }

        public void BanPerson()
        {
            int number;

            Console.Write("Введите идентификатор игрока которого желаете забанить: ");
            number = Utils.ReadInt();

            if (TryGetPlayer(number, out Player player))
            {
                if (player.IsBanned != true)
                {
                    player.BanAndUndbandle(true);
                }
                else
                {
                    Console.WriteLine("Игрок итак забанен!");
                    Console.ReadKey();
                }
            }
        }

        public void UnbanPerson()
        {
            int number;

            Console.Write("Введите идентификатор игрока которого желаете разбанить: ");
            number = Utils.ReadInt();

            if (TryGetPlayer(number, out Player player))
            {
                if (player.IsBanned != false)
                {
                    player.BanAndUndbandle(false);
                }
                else
                {
                    Console.WriteLine("Игрок итак разбанен!");
                    Console.ReadKey();
                }
            }
        }

        public void DeletePerson()
        {
            int number;

            Console.Write("Введите идентификатор игрока которого желаете удалить: ");
            number = Utils.ReadInt();

            if (TryGetPlayer(number, out Player player))
            {
                _listGamers.Remove(player);
            }
        }

        public void DrawBase()
        {
            if (_listGamers.Count > 0)
            {
                for (int i = 0; i < _listGamers.Count; i++)
                {
                    Console.Write($"\n Ник игрока - {_listGamers[i].Name} \nИдентификатор: {_listGamers[i].Id}" +
                        $"\nУровень: {_listGamers[i].Level}\nСостояние игрока: ");

                    if (_listGamers[i].IsBanned == false)
                    {
                        Console.WriteLine("разбанен");
                    }
                    else
                    {
                        Console.WriteLine("забанен");
                    }
                }
            }
            else
            {
                Console.WriteLine("Ни одного игрока нет\n" +
                    "пора что-то менять!");
            }

            Console.WriteLine();
        }

        private bool TryGetPlayer(int userInput, out Player player)
        {
            bool isNoResult = false;
            player = null;

            if (_listGamers.Count > 0)
            {
                for (int i = 0; i < _listGamers.Count; i++)
                {
                    if (_listGamers[i].Id == userInput)
                    {
                        player = _listGamers[i];
                        isNoResult = true;
                    }
                }
            }
            else
            {
                Console.WriteLine("\n База данных пуста");
                Console.ReadKey();
            }

            if (isNoResult == false && _listGamers.Count > 0)
            {
                Console.WriteLine("\nТакого нет, вводите внимательнее!");
                Console.ReadKey();
            }

            return isNoResult;
        }
    }

    class Utils
    {
        public static string GetNamePerson()
        {
            string name = "ОшИбКаqwer";
            bool isOpen = true;

            while (isOpen)
            {
                name = Console.ReadLine();
                Console.WriteLine();

                if (name != "")
                {
                    isOpen = false;
                }
                else
                {
                    Console.Write("Ошибочка, имя не может быть пустым!\n" +
                        "\nВведите имя снова:");
                }
            }

            return name;
        }

        public static int GetUniqueNumber(int number)
        {
            number++;

            return number;
        }

        public static int GetNumber(int minValue, int maxValue)
        {
            int number = 0;
            bool isOpen = true;

            while (isOpen)
            {
                number = ReadInt();

                if (number >= minValue && number <= maxValue)
                {
                    isOpen = false;
                }
                else
                {
                    Console.WriteLine("\nТакого пунта меню нет, странно..." +
                        "\n Попробуй снова!");
                }
            }

            Console.CursorVisible = true;

            return number;
        }

        public static void DrawMenu(int CommandAddPlayer, int CommandBanPlayer, int CommandUnbandlePlayer, int CommandRemovePlayer, int CommandExit)
        {
            int yCoordinate = 0;
            int xCoordinate = 60;

            ConsoleColor defaultColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.DarkGreen;

            Console.SetCursorPosition(xCoordinate, yCoordinate);
            yCoordinate++;

            Console.SetCursorPosition(xCoordinate, yCoordinate);
            Console.WriteLine($"{CommandAddPlayer}) Добавить игрока.");
            yCoordinate++;

            Console.SetCursorPosition(xCoordinate, yCoordinate);
            Console.WriteLine($"{CommandBanPlayer}) Забанить игрока.");
            yCoordinate++;

            Console.SetCursorPosition(xCoordinate, yCoordinate);
            Console.WriteLine($"{CommandUnbandlePlayer}) Разбанить игрока.");
            yCoordinate++;

            Console.SetCursorPosition(xCoordinate, yCoordinate);
            Console.WriteLine($"{CommandRemovePlayer}) Удалить игрока.");
            yCoordinate++;

            Console.SetCursorPosition(xCoordinate, yCoordinate);
            Console.WriteLine($"{CommandExit}) Выйти из программы.");

            Console.ForegroundColor = defaultColor;
        }

        public static int ReadInt()
        {
            string userInput;
            int result = 0;
            bool isOpen = true;

            while (isOpen)
            {
                userInput = Console.ReadLine();

                if (int.TryParse(userInput, out int number))
                {
                    result = number;
                    isOpen = false;
                }
                else
                {
                    Console.Write("\nОшибка, это не число.\nВводите по новой: ");
                }
            }

            return result;
        }
    }
}