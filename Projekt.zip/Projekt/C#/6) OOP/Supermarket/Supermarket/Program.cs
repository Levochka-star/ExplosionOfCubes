﻿using System;
using System.Collections.Generic;

namespace Supermarket
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Mall mall = new Mall();

            mall.Work();
        }
    }

    class Mall
    {
        private List<Product> _products = new List<Product>();
        private Queue<Client> _clients = new Queue<Client>();
        private int _clientsServiced;
        private int _money;

        public Mall()
        {
            _products.Add(new Product("Водка \"Онегин\"", 1200));
            _products.Add(new Product("Уголь", 650));
            _products.Add(new Product("Печенье \"Курабье\"", 600));
            _products.Add(new Product("Корма", 289));
            _products.Add(new Product("Сирдр", 200));
            _products.Add(new Product("Картошка", 190));
            _products.Add(new Product("Чипсы", 156));
            _products.Add(new Product("Перец молотый", 120));
            _products.Add(new Product("Чоколадка", 100));
            _products.Add(new Product("Масло подсолнечное", 98));
            _products.Add(new Product("Горчица", 80));
            _products.Add(new Product("Вода \"Шишкин лес\"", 80));
            _products.Add(new Product("Уксус", 68));
            _products.Add(new Product("Мороженное", 48));
            _products.Add(new Product("Помидори", 45));
            _products.Add(new Product("Конфеты", 19));
        }

        public void Work()
        {
            bool isWork = true;

            int minValueClients = 5;
            int maxValueClients = 20;

            int maxValueClientMoney = 5000;

            while (isWork)
            {
                Console.Clear();
                FillingClients(minValueClients, maxValueClients, maxValueClientMoney);

                Console.WriteLine($"Счет супермаркета: {_money}руб.");
                ShowServedCustomers();
                Console.WriteLine($"В очереди клиентов: {_clients.Count}чел.\n");

                Service();
                Console.ReadKey();
            }
        }

        private void Service()
        {
            Console.WriteLine("На кассу подходит клиент:");

            Client client = _clients.Peek();

            int fullCost = client.GetSumCost();

            Console.WriteLine($"Деньги клиента: {client.Money}руб.");
            client.ShowBasket();
            Console.ReadKey();

            if (client.Money >= fullCost)
            {
                client = _clients.Dequeue();

                client.MakePurchase();
                _money += fullCost;

                ValidPurchase(client, fullCost);
            }
            else
            {
                int differenceSum = client.GetSumCost() - client.Money;

                Console.WriteLine($"\nКлиенту нехватило {differenceSum}руб.\nНажмите любую клавишу..");
                Console.ReadKey();
                Console.WriteLine("Клиент вынужден отойти и выложить часть продуктов!\n");

                client.RemoveProductFromFoodBasket();
            }
        }

        private void ValidPurchase(Client client, int fullCost)
        {
            if (client.BagCount > 0)
            {
                Console.WriteLine($"\nПокупка прошла успешно на счет зачислено {fullCost}руб.");
                Console.WriteLine($"Остаток клиента: {client.Money}руб.");

                _clientsServiced += 1;
            }
            else
            {
                Console.WriteLine($"Покупка не прошла! Клиент не смог ничего вырбрать.");
            }
        }

        private void ShowServedCustomers()
        {
            if (_clientsServiced > 0)
            {
                Console.WriteLine($"Обслужено клиентов: {_clientsServiced}чел.");
            }
        }

        private void FillingClients(int minValueClients, int maxValueClients, int maxValueMoney)
        {
            int currentValueClient = Utils.GetPositiveNumber(minValueClients, maxValueClients);

            if (_clients.Count < minValueClients)
            {
                for (int i = 0; i < currentValueClient; i++)
                {
                    _clients.Enqueue(new Client(new List <Product>(_products), maxValueMoney));
                }
            }
        }
    }

    class Product
    {
        public Product(string name, int price)
        {
            Name = name;
            Price = price;
        }

        public string Name { get; private set; }
        public int Price { get; private set; }
    }

    class Client
    {
        private Queue<Product> _foodBasket = new Queue<Product>();
        private List<Product> _bag = new List<Product>();

        public Client(List<Product> products, int maxValueMoney)
        {
            Money = GenerateMoney(maxValueMoney);
            FillingBasket(products);
        }

        public int Money { get; private set; }
        public int BagCount => _bag.Count;

        public void RemoveProductFromFoodBasket()
        {
            while (Money < GetSumCost())
            {
                Console.WriteLine("Из корзины удален товар: " + '"' + _foodBasket.Dequeue().Name + '"');
            }
        }

        public void ShowBasket()
        {
            Console.WriteLine();
            Console.Write("В корзине продукты:");

            if (_foodBasket.Count > 0)
            {
                Console.WriteLine();

                foreach (Product products in _foodBasket)
                {
                    Console.WriteLine($"{products.Name} по цене {products.Price}руб.");
                }
            }
            else
            {
                Console.WriteLine(" отсутствуют!");
            }
        }

        public int GetSumCost()
        {
            int fullCost = 0;

            foreach (Product products in _foodBasket)
            {
                fullCost += products.Price;
            }

            return fullCost;
        }

        public void MakePurchase()
        {
            Console.WriteLine();

            while (_foodBasket.Count > 0)
            {
                Product product = TakeProduct(_foodBasket);
                _bag.Add(product);

                Console.WriteLine($"В сумку положен продукт \"{product.Name}\" по цене {product.Price}руб.");
            }
        }

        private Product TakeProduct(Queue<Product> products)
        {
            Product product = new Product(products.Peek().Name, products.Peek().Price);
            products.Dequeue();
            Money -= product.Price;

            return product;
        }

        private void FillingBasket(List<Product> products)
        {
            int minProductsInBasket = 2;
            int maxProductsInBasket = 6;

            for (int i = 0; i < Utils.GetPositiveNumber(minProductsInBasket, maxProductsInBasket); i++)
            {
                int indexDesiredProduct = Utils.GetPositiveNumber(products.Count - 1);

                _foodBasket.Enqueue(new Product(products[indexDesiredProduct].Name, products[indexDesiredProduct].Price));
            }
        }

        private int GenerateMoney(int maxMoney)
        {
            return Utils.GetPositiveNumber(maxMoney);
        }
    }

    class Utils
    {
        private static Random s_random = new Random();
        
        public static int GetPositiveNumber(int maxNumber)
        {
            return s_random.Next(maxNumber + 1);
        }

        public static int GetPositiveNumber(int minNumber, int maxNumber)
        {
            return s_random.Next(minNumber, maxNumber + 1);
        }
    }
}