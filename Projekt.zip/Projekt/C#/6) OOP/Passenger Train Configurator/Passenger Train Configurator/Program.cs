﻿using System;
using System.Collections.Generic;

namespace Passenger_Train_Configurator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DispatcherView dispatcherView = new DispatcherView();

            dispatcherView.Work();
        }
    }

    class DispatcherView
    {
        public void Work()
        {
            const int CommandCreateTrain = 1;
            const int CommandExit = 2;

            bool isWork = true;

            Dispatcher dispatcher = new Dispatcher();

            while (isWork)
            {
                Console.Clear();
                dispatcher.ShowListTrain();

                Console.WriteLine($"{CommandCreateTrain}) созданиe поезда." +
                    $"\n{CommandExit}) завершениe работы.");
                Console.WriteLine();

                switch (Utils.ReadInt())
                {
                    case CommandCreateTrain:
                        dispatcher.Work();
                        break;

                    case CommandExit:
                        isWork = false;
                        break;

                    default:
                        IncorrectInput();
                        break;
                }
            }
        }

        private void IncorrectInput()
        {
            Console.Clear();
            Console.WriteLine("Такого пункта нет");
            Console.ReadKey();
        }
    }

    class Dispatcher
    {
        private List<Train> _trains = new List<Train>();

        public void Work()
        {
            int valueLastTrain;

            Console.Clear();
            Console.WriteLine("Создайте направление:");
            Direction direction = CreateDirection();

            Console.Clear();
            int numberPassengers = GetRandomNumberPassengers();
            Console.WriteLine($"Число пассажиров купивших билет на данное направление: {numberPassengers}");
            Console.WriteLine();
            Console.ReadKey();

            Console.Clear();
            _trains.Add(Create(direction, numberPassengers));
            valueLastTrain = _trains.Count - 1;

            ShowInfoTrain(valueLastTrain);
            Console.ReadLine();
        }

        public void ShowListTrain()
        {
            if (_trains.Count > 0)
            {
                for (int i = 0; i < _trains.Count; i++)
                {
                    Train train = _trains[i];
                    Console.WriteLine($"\"{train.Direction.Start} -> " +
                                $"{train.Direction.End}\" | " +
                    $"Вагоны: {train.WagonsCount} шт. | " +
                    $"Людей на посадку: {train.NumberPassengers} чел.");
                }

                Console.WriteLine();
            }
        }

        private void ShowInfoTrain(int valueLastTrain)
        {
            Train train = _trains[valueLastTrain];

            Console.WriteLine("Информация о созданном поезде:\n" +
                            $"Проследует по направлению: \"{train.Direction.Start} -> " +
                            $"{train.Direction.End}\".\n" +
                                $"Вагонов следования: {train.WagonsCount}.\n" +
                                $"Людей на посадку: {train.NumberPassengers}.");
        }

        private Direction CreateDirection()
        {
            bool isWork = true;
            string start = "";
            string end = "";

            while (isWork)
            {
                Console.Write("Введите название начальной точки: ");
                start = Utils.IsNullOrEmpty();

                Console.Write("Введите название конечной точики: ");
                end = Utils.IsNullOrEmpty();

                if (start != end)
                {
                    isWork = false;
                }
                else
                {
                    Console.WriteLine("\nПлохо! Выбрана одна точка, попробуй снова..");
                }
            }

            return new Direction(start, end);
        }

        private int GetRandomNumberPassengers()
        {
            int minValuePassenger = 0;
            int valuePassenger = 800;

            return Utils.GetRandomNumber(minValuePassenger, valuePassenger);
        }

        private Train Create(Direction direction, int numberPassengers)
        {
            List<Wagon> wagons = new List<Wagon>();

            int seats = 36;
            int numberAllPassengers = numberPassengers;

            for (int i = 0; i < numberAllPassengers; i++)
            {
                wagons.Add(new Wagon(seats));
                numberAllPassengers -= wagons[i].ValueSeats;
            }

            return new Train(wagons, numberPassengers, direction);
        }
    }

    class Direction
    {
        public Direction(string directionStart, string directionEnd)
        {
            Start = directionStart;
            End = directionEnd;
        }

        public string Start { get; private set; }
        public string End { get; private set; }
    }

    class Wagon
    {
        public Wagon(int numberPassengers)
        {
            NumberPassengers = numberPassengers;
        }

        public int ValueSeats => 36;
        public int NumberPassengers{ get; private set;}
    }

    class Train
    {
        private List<Wagon> _wagons;

        public Train(List<Wagon> wagons, int numberPassengers, Direction direction)
        {
            Direction = direction;
            _wagons = wagons;
            NumberPassengers = numberPassengers;
        }

        public Direction Direction { get; private set; }
        public int NumberPassengers { get; private set; }

        public int WagonsCount => _wagons.Count;
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static int GetRandomNumber(int minNumber, int maxNumber)
        {
            return s_random.Next(minNumber, maxNumber + 1);
        }

        public static int ReadInt()
        {
            bool isOpen = true;
            string inputNumber;
            int results = 0;

            while (isOpen)
            {
                Console.Write($"Введите пункт меню: ");
                inputNumber = Console.ReadLine();

                if (int.TryParse(inputNumber, out int number))
                {
                    results = number;
                    isOpen = false;
                }
                else
                {
                    Console.Write($"Попробуйте снова! Нажмите любую клавишу");
                    Console.ReadKey();
                }
            }

            return results;
        }

        public static string IsNullOrEmpty()
        {
            bool isOpen = true;
            string inputUser;
            string result = "";

            while (isOpen)
            {
                inputUser = Console.ReadLine();

                if (inputUser != "")
                {
                    result = inputUser;
                    isOpen = false;
                }
                else
                {
                    Console.WriteLine("\nВведена пустая строка.\nПопробуй снова!");
                }
            }

            return result;
        }
    }
}