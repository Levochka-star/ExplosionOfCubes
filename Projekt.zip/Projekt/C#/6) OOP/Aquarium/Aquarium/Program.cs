﻿using System;
using System.Collections.Generic;

namespace Aquarium
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AquariumPacketOperator AquariumPacketOperator = new AquariumPacketOperator();
            AquariumPacketOperator.Work();
        }
    }

    class AquariumPacketOperator
    {
        public void Work()
        {
            const string CommandAddFishInAquarium = "1";
            const string CommandAddFishInPacket = "2";

            Aquarium aquarium = new Aquarium();
            Packet packet = new Packet();

            bool isWork = true;

            int dayOfLife = 0;

            while (isWork)
            {
                dayOfLife++;
              
                ShowMenu(CommandAddFishInAquarium, CommandAddFishInPacket, aquarium, packet, dayOfLife);

                switch (Console.ReadLine())
                {
                    case CommandAddFishInAquarium:
                        AddFishInAquarium(aquarium, packet);
                        break;

                    case CommandAddFishInPacket:
                        AddFishInPacket(aquarium, packet);
                        break;

                    default:
                        SkipDay();
                        break;
                }

                aquarium.AgingOfFish();

                isWork = TryFindLiveFish(aquarium, packet, dayOfLife);
            }
        }

        private void ShowMenu(string commandAddFishInAquarium, string commandAddFishInPacket, Aquarium aquarium, Packet packet, int dayOfLife)
        {
            Console.Clear();
            Console.WriteLine($"День {dayOfLife}");

            Console.WriteLine($"{commandAddFishInAquarium} - нажмите для перемещения рыбы в аквариум\n" +
                $"{commandAddFishInPacket} - нажмите для перемещения рыбы в пакет\n" +
                $"Нажмите любую клавишу для скипа дня\n");

            Console.WriteLine("\nАквариум:");
            aquarium.ShowFish();
            Console.WriteLine("\nПакет рыбы:");
            packet.ShowFish();
            Console.WriteLine();
        }

        private void AddFishInAquarium(Aquarium aquarium, Packet packet)
        {
            Console.Clear();

            if (packet.FishCount > 0)
            {
                int indexfish;

                Console.WriteLine("Выберите рыбу в хранилище:");
                packet.ShowFish();
                indexfish = Utils.GetNumberPositiveInRange(packet.FishCount);

                aquarium.AddFish(indexfish, packet);
            }
            else
            {
                ShowInfoLackFish("хранилище");
            }
        }

        private void AddFishInPacket(Aquarium aquarium, Packet packet)
        {
            Console.Clear();

            if (aquarium.FishCount > 0)
            {
                int indexfish;

                Console.WriteLine("Выберите рыбу в аквариуме:");
                aquarium.ShowFish();
                indexfish = Utils.GetNumberPositiveInRange(aquarium.FishCount);

                packet.AddFish(aquarium.TakeFish(indexfish));
            }
            else
            {
                ShowInfoLackFish("аквариуме");
            }
        }

        private void SkipDay()
        {
            Console.Clear();
            Console.WriteLine("День будет пропущен.");
            Console.ReadKey();
        }

        private bool TryFindLiveFish(Aquarium aquarium, Packet packet, int dayOfLife)
        {
            bool isWork = false;

            if (aquarium.FishCount == 0 && packet.FishCount == 0)
            {
                Console.Clear();
                Console.WriteLine($"У вас новое достижение: " +
                    $"Вы расправились со своими питомцами быстрее чем за {dayOfLife}");
                Console.ReadKey();
                isWork = false;
            }
            else
            {
                isWork = true;
            }

            return isWork;
        }

        private void ShowInfoLackFish(string storage)
        {
            Console.Clear();
            Console.WriteLine($"В {storage} не осталось рыб!");
            Console.ReadKey();
        }
    }

    class Container
    {
        protected List<Fish> Fishes = new List<Fish>();

        public int FishCount => Fishes.Count;

        public void ShowFish()
        {
            if (FishCount != 0)
            {
                for (int i = 0; i < Fishes.Count; i++)
                {
                    int numberFish = i + 1;

                    Console.WriteLine($"{numberFish}) {Fishes[i].Name} осталось дней жизни {Fishes[i].ValueLifeUnits}");
                }
            }
            else
            {
                Console.WriteLine("Рыба отсутствует..");
            }
        }

        public Fish TakeFish(int numberFish)
        {
            int indexFish = numberFish - 1;
            Fish fish = Fishes[indexFish];
            RemoveFish(indexFish);
            return fish;
        }

        protected void RemoveFish(int indexFish)
        {
            Fishes.RemoveAt(indexFish);
        }

        protected void ShowResultTransfer()
        {
            Console.Clear();
            Console.WriteLine("Рыба была удачно перемещена!");
            Console.ReadKey();
        }
    }

    class Aquarium : Container
    {
        private int _maxCountFish = 3;

        public void AddFish(int indexFish, Container fish)
        {
            if (Fishes.Count < _maxCountFish)
            {
                Fishes.Add(fish.TakeFish(indexFish));
                ShowResultTransfer();
            }
            else
            {
                Console.Clear();
                Console.WriteLine($"Аквариум переполнен, количество рыб: {Fishes.Count}");
                Console.ReadKey();
            }
        }

        public void AgingOfFish()
        {
            foreach (Fish fish in Fishes)
            {
                fish.RemoveLifeUnit();
            }

            for (int i = Fishes.Count - 1; i >= 0; i--)
            {
                if (Fishes[i].ValueLifeUnits <= 0)
                {
                    RemoveFish(i);
                }
            }
        }
    }

    class Packet : Container
    {
        private Factory _fishFabric = new Factory();

        public Packet()
        {
            Fishes = _fishFabric.CreateFish();
        }

        public void AddFish(Fish fish)
        {
            Fishes.Add(fish);
            ShowResultTransfer();
        }
    }

    class Fish
    {
        private int _lifeUnits = 80;

        public Fish(string name, int daysOfLife)
        {
            ValueLifeUnits = daysOfLife / _lifeUnits;
            Name = name;
        }

        public int ValueLifeUnits { get; private set; }
        public string Name { get; private set; }

        public void RemoveLifeUnit()
        {
            ValueLifeUnits -= 1;
        }
    }

    class Factory
    {
        public List<Fish> CreateFish()
        {
            return new List<Fish>
                {
                new Fish ("Гуппи", GetDaysOfLife(900, 1800)),
                new Fish ("Данио реррио", GetDaysOfLife(1095, 2555)),
                new Fish ("Кардинал", GetDaysOfLife(1095, 2555)),
                new Fish ("Барбус суматранский", GetDaysOfLife(1825, 3650)),
                new Fish ("Скалярия", GetDaysOfLife(2555, 3650)),
                new Fish ("Неон", GetDaysOfLife(1825, 3650)),
                new Fish ("Тернеция", GetDaysOfLife(1825, 3650)),
                new Fish ("Золотая рыбка", GetDaysOfLife(3650, 10950))
            };
        }

        private int GetDaysOfLife(int minDaysOfLife, int maxDaysOfLife)
        {
            return Utils.GenerateNumberInRange(minDaysOfLife, maxDaysOfLife);
        }
    }

    class Utils
    {
        private static Random _random = new Random();

        public static int GenerateNumberInRange(int minNumber, int maxNumber)
        {
            return _random.Next(minNumber, maxNumber++);
        }

        public static int GetNumberPositiveInRange(int maxNumber)
        {
            bool isOpen = true;
            string inputUser;
            int result = 0;

            while (isOpen)
            {
                inputUser = Console.ReadLine();

                if (int.TryParse(inputUser, out result) && result > 0 && result <= maxNumber)
                {
                    isOpen = false;
                }
                else
                {
                    Console.Write("\nТакого нет.\nПопробуй ввести сейчас: ");
                }
            }

            return result;
        }
    }
}