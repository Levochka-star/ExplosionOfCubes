﻿using System;
using System.Collections.Generic;

namespace ZoologicalGarden
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AviaryFactory factory = new AviaryFactory();
            Zoo zoo = new Zoo(factory);

            zoo.Work();
        }
    }

    class Zoo
    {
        private List<Aviary> _aviaries = new List<Aviary>();

        public Zoo(AviaryFactory factory)
        {
            _aviaries = factory.Create();
        }

        public void Work()
        {
            bool isWork = true;
            int valueIterationsWork = 0;

            Console.WriteLine("Вы в зоопарке!");
            Console.ReadKey();

            while (isWork)
            {
                Console.Clear();

                valueIterationsWork++;

                int indexAviary = (ShowMenu(_aviaries) - 1);

                _aviaries[indexAviary].ShowInfo();

                if (valueIterationsWork >= _aviaries.Count)
                {
                    isWork = NeedContinue();
                }
            }
        }

        private bool NeedContinue()
        {
            bool isWork = true;

            string confirm = "д";
            string enter ="Enter";
            Console.WriteLine($"\nЖелаете уйти? Если да нажмите \"{confirm}\" и {enter}," +
                $"\nесли нет: \"любую клавишу\" и {enter} либо один раз {enter}..");

            if (Console.ReadLine() == confirm)
            {
                isWork = false;
            }

            return isWork;
        }

        private int ShowMenu(List<Aviary> aviaries)
        {
            int numberMenu = 0;

            for (int i = 0; i < aviaries.Count; i++)
            {
                numberMenu++;

                Console.WriteLine($"{numberMenu} - если хотите подойти к вольеру где содержат {aviaries[i].NameAnimals}.");
            }

            return numberMenu = Utils.GetNumberPositiveInRange(aviaries.Count);
        }
    }

    class Aviary
    {
        private List<Animal> _animals;

        public Aviary(string nameAnimals, List<Animal> animals)
        {
            NameAnimals = nameAnimals;
            _animals = animals;
        }

        public string NameAnimals { get; private set; }

        public void ShowInfo()
        {
            Console.Clear();
            Console.WriteLine($"Вы подходите к вольеру где содержат: {NameAnimals}");
            Console.WriteLine($"Слышите как животные издают звук: {_animals[_animals.Count -1].Voice}.");

            for (int i = 0; i < _animals.Count; i++)
            {
                Console.WriteLine($"{_animals[i].Name} - {_animals[i].Sex}.");
            }

            Console.ReadKey();
        }
    }

    class Animal
    {
        public Animal(string voise, string name, string sex)
        {
            Voice = voise;
            Name = name;
            Sex = sex;
        }

        public string Voice { get; private set; }                             
        public string Name { get; private set; }
        public string Sex { get; private set; }
    }

    class AviaryFactory
    {
        public List<Aviary> Create()
        {
            List<Aviary> aviaries = new List<Aviary>
            {
                new Aviary("попугаев", GenerateAnimals("громкий, хриплый", "Ара")),
                new Aviary("диких кошек", GenerateAnimals("будто пилка по дереву, отрывистый","Леопард")),
                new Aviary("обезьян", GenerateAnimals("уууу-аааа-а-а-а-а! Ху-ху-ху-ху", "Шимпанзе")),
                new Aviary("крокодилов",  GenerateAnimals("будто кто-то мычит","Кайман"))
            };

            return aviaries;
        }

        private List<Animal> GenerateAnimals(string voice, string name)
        {
            List<Animal> animals = new List<Animal>();

            int minValueAnimals = 3;
            int maxValueAnimals = 12;

            int valueAnimals = Utils.GenerateNumberInRange(minValueAnimals, maxValueAnimals);

            for (int i = 0; i < valueAnimals; i++)
            {
                string sex = GenerateSex();

                animals.Add(new Animal(voice, name, sex));
            }

            return animals;
        }
        private string GenerateSex()
        {
            string male = "самец";        
            string female = "самка";
            string [] genders = new string [] { male, female};

            return genders[Utils.GenerateNumberInRange(genders.Length)];
        }
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static int GenerateNumberInRange(int minNumber, int maxNumber)
        {
            return s_random.Next(minNumber, maxNumber++);
        }

        public static int GenerateNumberInRange(int maxNumber)
        {
            return s_random.Next(maxNumber++);
        }

        public static int GetNumberPositiveInRange(int maxNumber)
        {
            bool isOpen = true;
            string inputUser;
            int result = 0;

            while (isOpen)
            {
                inputUser = Console.ReadLine();

                if (int.TryParse(inputUser, out result) && result > 0 && result <= maxNumber)
                {
                    isOpen = false;
                }
                else
                {
                    Console.Write("\nТакого нет.\nПопробуй ввести сейчас: ");
                }
            }

            return result;
        }
    }
}