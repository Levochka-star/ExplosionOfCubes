﻿using System;
using System.Collections.Generic;

namespace Storage_book
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int CommandAddBook = 1;
            const int CommandShowBooks = 2;
            const int CommandRemoveBook = 3;
            const int CommandSearchName = 4;
            const int CommandSearchAuthor = 5;
            const int CommandSearchBooksPerYear = 6;
            const int CommandExit = 7;

            int maxNumberMenu = CommandExit;

            bool isOpen = true;

            RendererMenu rendererMenu = new RendererMenu();
            StorageBook books = new StorageBook();

            rendererMenu.DrawGreeting();

            while (isOpen)
            {
                Console.Clear();

                rendererMenu.DrawMenuProgram(CommandAddBook, CommandShowBooks, CommandRemoveBook, CommandSearchName, CommandSearchAuthor, CommandSearchBooksPerYear, CommandExit);

                switch (Utils.GetNumberInRange(maxNumberMenu))
                {
                    case CommandAddBook:
                        books.AddBook();
                        break;

                    case CommandShowBooks:
                        books.ShowBooks();
                        Console.ReadKey();
                        break;

                    case CommandRemoveBook:
                        books.RemoveBook();
                        books.ShowBooks();
                        Console.ReadKey();
                        break;

                    case CommandSearchName:
                        books.SearchName();
                        break;

                    case CommandSearchAuthor:
                        books.SearchNameAuthor();
                        break;

                    case CommandSearchBooksPerYear:
                        books.SearchBooksPerYear();
                        break;

                    case CommandExit:
                        isOpen = false;
                        break;
                }
            }
        }
    }

    class RendererMenu
    {
        public void DrawGreeting()
        {
            Console.Write("Вы попали в хранилище книг, но оно пока пустует." +
                "\nПора добавлять книги!");
            Console.ReadKey();
        }

        public void DrawMenuProgram(int commandAddBook, int commandShowBooks, int commandRemoveBook, int commandSearchName, int commandSearchAuthor, int commandSearchYear, int commandExit)
        {
            Console.SetCursorPosition(8, 0);
            Console.WriteLine("Меню");

            Console.SetCursorPosition(0, 2);
            Console.WriteLine($"{commandAddBook}) Добавить книгу." +
                $"\n{commandShowBooks}) Показать книги." +
                $"\n{commandRemoveBook}) Убрать книгу." +
                $"\n{commandSearchName}) Найти книгу по имени." +
                $"\n{commandSearchAuthor}) Найти книгу по автору." +
                $"\n{commandSearchYear}) Найти книгу по году." +
                $"\n{commandExit}) Выйти из программы.");
            Console.WriteLine();
            Console.Write("Выберите пункт: ");
        }
    }

    class Book
    {
        public Book(string name, string author, int yearRelease)
        {
            Name = name;
            Author = author;
            YearRelease = yearRelease;
        }

        public string Name { get; private set; }
        public string Author { get; private set; }
        public int YearRelease { get; private set; }
    }

    class StorageBook
    {
        private List<Book> _books = new List<Book>();

        public void AddBook()
        {
            EnquireDataBook("название");
            string nameBook = Utils.IsNullOrEmpty();

            EnquireDataBook("автор");
            string authorBook = Utils.IsNullOrEmpty();

            EnquireDataBook("год издания");
            int yearsRelease = Utils.GetNumberYear();

            _books.Add(new Book(nameBook, authorBook, yearsRelease));
        }

        public void ShowBooks()
        {
            Console.Clear();
            Console.WriteLine("Список доступных книг");

            DrawBooks();
        }

        public void SearchName()
        {
            Console.Clear();
            Console.Write("Введите название книги: ");
            string nameBook = Utils.IsNullOrEmpty();

            if (CanFindNameBook(nameBook, out List<int> indexesNames))
            {
                ShowTotalBook(indexesNames);
                Console.ReadKey();
            }
            else
            {
                HasNotParameter("с именем", nameBook);
            }

        }

        public void SearchNameAuthor()
        {
            Console.Clear();
            Console.Write("Введите имя автора: ");
            string nameAuthor = Utils.IsNullOrEmpty();

            if (CanFindNameAuthor(nameAuthor, out List<int> indexesNameAutor))
            {
                ShowTotalBook(indexesNameAutor);
                Console.ReadKey();
            }
            else
            {
                HasNotParameter("под автороством", nameAuthor);
            }

        }

        public void SearchBooksPerYear()
        {
            Console.Clear();
            Console.Write("Введите год публикации книги: ");
            int yearRelease = Utils.GetNumberYear();

            if (CanFindBooksPerYear(yearRelease, out List<int> indexesBooksPerYear))
            {
                ShowTotalBook(indexesBooksPerYear);
                Console.ReadKey();
            }
            else
            {
                HasNotParameter("c годом публикации", yearRelease);
            }

        }

        public void RemoveBook()
        {
            Console.Clear();
            DrawBooks();

            Console.WriteLine();
            Console.Write("Выберите номер книги который желаете удалить: ");
            int numberBook = Utils.GetNumberInRange(_books.Count);

            _books.RemoveAt(numberBook - 1);
        }

        private static void HasNotParameter(string nameParameter, string parameter)
        {
            Console.WriteLine($"\nКниг {nameParameter} {parameter} не найдено!");
            Console.ReadKey();
        }

        private static void HasNotParameter(string nameParameter, int parameter)
        {
            Console.WriteLine($"\nКниг {nameParameter} {parameter} не найдено!");
            Console.ReadKey();
        }

        private void ShowTotalBook(List<int> indexesParameter)
        {
            for (int i = 0; i < indexesParameter.Count; i++)
            {
                int numberBook = i + 1;

                Console.WriteLine($"{numberBook}. \"{_books[indexesParameter[i]].Name}\" " +
                    $"{_books[indexesParameter[i]].Author} " +
                    $"{_books[indexesParameter[i]].YearRelease}г.");
            }
        }

        private bool CanFindNameBook(string nameBook, out List<int> indexesNames)
        {
            bool hasNameBook = false;

            indexesNames = new List<int>();

            for (int i = 0; i < _books.Count; i++)
            {
                if (nameBook == _books[i].Name)
                {
                    hasNameBook = true;
                    indexesNames.Add(i);
                }
            }

            return hasNameBook;
        }

        private bool CanFindNameAuthor(string nameAuthors, out List<int> indexNamesAuthor)
        {
            indexNamesAuthor = new List<int>();

            bool hasNameAuthors = false;

            for (int i = 0; i < _books.Count; i++)
            {
                if (nameAuthors == _books[i].Author)
                {
                    hasNameAuthors = true;
                    indexNamesAuthor.Add(i);
                }
            }

            return hasNameAuthors;
        }

        private bool CanFindBooksPerYear(int booksInYear, out List<int> indexBooksPerYear)
        {
            bool hasYear = false;

            indexBooksPerYear = new List<int>();

            for (int i = 0; i < _books.Count; i++)
            {
                if (booksInYear == _books[i].YearRelease)
                {
                    hasYear = true;
                    indexBooksPerYear.Add(i);
                }
            }

            return hasYear;
        }

        private void DrawBooks()
        {
            for (int i = 0; i < _books.Count; i++)
            {
                int numberBook = i + 1;

                Console.WriteLine($"{numberBook}. \"{_books[i].Name}\" {_books[i].Author} {_books[i].YearRelease}г.");
            }
        }

        private void EnquireDataBook(string nameParameter)
        {
            Console.Clear();
            Console.WriteLine("Введите следующие данные о книге:");
            Console.Write($"- {nameParameter}: ");
        }
    }

    class Utils
    {
        public static int GetNumberInRange(int maxNumberMenu)
        {
            bool isOpen = true;
            string inputUser;
            int result = 0;

            while (isOpen)
            {
                inputUser = Console.ReadLine();

                if (int.TryParse(inputUser, out result) && result > 0 && result <= maxNumberMenu)
                {
                    isOpen = false;
                }
                else
                {
                    Console.WriteLine("\nТакого нет.\nПопробуй снова!");
                }
            }

            return result;
        }

        public static int GetNumberYear()
        {
            bool isOpen = true;
            string inputUser;
            int result = 0;

            while (isOpen)
            {
                inputUser = Console.ReadLine();

                if (int.TryParse(inputUser, out result) && result > 0)
                {
                    isOpen = false;
                }
                else
                {
                    Console.WriteLine("\nВведён не год.\nПопробуй снова!");
                }
            }

            return result;
        }

        public static string IsNullOrEmpty()
        {
            bool isOpen = true;
            string inputUser;
            string result = "";

            while (isOpen)
            {
                inputUser = Console.ReadLine();

                if (inputUser != "")
                {
                    result = inputUser;
                    isOpen = false;
                }
                else
                {
                    Console.WriteLine("\nВведена пустая строка.\nПопробуй снова!");
                }
            }

            return result;
        }
    }
}