﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace amnesty
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CulpritsFactory culpritsFactory = new CulpritsFactory();
            Government goverment = new Government(culpritsFactory);

            goverment.Work();
        }
    }

    class Government
    {
        private List<Culprit> _culprits;

        private int _culpritsCount = 20;

        private string _nameCrime = "Антиправительственное";

        public Government(CulpritsFactory culpritsFactory)
        {
            _culprits = culpritsFactory.Generate(_culpritsCount);
        }

        public void Work()
        {
            ShowInfo();

            Console.WriteLine($"\nВсех людей, заключенных за преступление \"{_nameCrime}\", следует освободить!\n");
            Console.ReadKey();

            RemoveCrime(_nameCrime);
            ShowInfo();

            Console.ReadKey();
        }

        private void ShowInfo()
        {
            for (int i = 0; i < _culprits.Count; i++)
            {
                Console.WriteLine($"{_culprits[i].FullName} Преступление:{_culprits[i].NameCrime}");
            }
        }

        private void RemoveCrime(string crime)
        {
            _culprits = _culprits.Where(culprit => culprit.NameCrime != crime).ToList();
        }
    }

    class CulpritsFactory
    {
        private List<string> _firstNames = new List<string>();
        private List<string> _middleNames = new List<string>();
        private List<string> _lastNames = new List<string>();
        private List<string> _nameCrime = new List<string>();

        public CulpritsFactory()
        {
            _firstNames.Add("Сергей");
            _firstNames.Add("Михаил");
            _firstNames.Add("Александр");
            _firstNames.Add("Вячеслав");
            _firstNames.Add("Пётр");

            _middleNames.Add("Гусев");
            _middleNames.Add("Левин");
            _middleNames.Add("Хомяков");
            _middleNames.Add("Юдин");
            _middleNames.Add("Корниненко");

            _lastNames.Add("Андреевич");
            _lastNames.Add("Евгеньевич");
            _lastNames.Add("Дмитреевич");
            _lastNames.Add("Тимовеевич");
            _lastNames.Add("Викторович");

            _nameCrime.Add("Антиправительственное");
            _nameCrime.Add("Насильственное");
            _nameCrime.Add("Взяточное");
        }

        public List<Culprit> Generate(int culpritsCount)
        {
            List<Culprit> culprits = new List<Culprit>();

            for (int i = 0; i < culpritsCount; i++)
            {
                string nameCrime = _nameCrime[Utils.GenerateNumberInRange(_nameCrime.Count)];
                culprits.Add(new Culprit(GetFullName(), nameCrime));
            }

            return culprits;
        }

        private string GetFullName()
        {
            string fullName, firstName, middleName, lastName;

            firstName = _firstNames[Utils.GenerateNumberInRange(_firstNames.Count)];
            middleName = _middleNames[Utils.GenerateNumberInRange(_middleNames.Count)];
            lastName = _lastNames[Utils.GenerateNumberInRange(_lastNames.Count)];

            return fullName = firstName + " " + middleName + " " + lastName;
        }
    }

    class Culprit
    {
        public Culprit(string fullName, string nameCrime)
        {
            FullName = fullName;
            NameCrime = nameCrime;
        }

        public string FullName { get; private set; }
        public string NameCrime { get; private set; }
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static int GenerateNumberInRange(int maxNumber)
        {
            return s_random.Next(maxNumber++);
        }
    }
}