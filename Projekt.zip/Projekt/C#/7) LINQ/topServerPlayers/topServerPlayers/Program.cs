﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace topServerPlayers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PlayersFactory playersFactory = new PlayersFactory();
            WinnersShield winnersShield = new WinnersShield(playersFactory);

            winnersShield.Work();
        }
    }

    class WinnersShield
    {
        private List<Player> _players = new List<Player>();

        private int _playersCount = 36;
        private int _seatsCount = 3;

        public WinnersShield(PlayersFactory playersFactory)
        {
            _players = playersFactory.Generate(_playersCount);
        }

        public void Work ()
        {
            Console.WriteLine("Топ игроков по уровню:");
            SortTopPlayersByLevel();

            Console.WriteLine("\nТоп игроков по силе:");
            SortTopPlayersByPower();
        }

        private void SortTopPlayersByPower()
        {
            var topPlayersByPower = _players.OrderByDescending(plauer => plauer.Power).Take(_seatsCount).ToList();

            ShowPlayers(topPlayersByPower);
        }

        private void SortTopPlayersByLevel()
        {
            var topPlayersByLevel = _players.OrderByDescending(plauer => plauer.Level).Take(_seatsCount).ToList();

            ShowPlayers(topPlayersByLevel);
        }

        private void ShowPlayers(List<Player> players)
        {
            foreach(var player in players)
            {
                Console.WriteLine($"{player.FullName} Сила:{player.Power} Уровень:{player.Level} ");
            }
        }
    }

    class Player
    {
        public Player(string fullName, int power, int level)
        {
            FullName = fullName;
            Power = power;
            Level = level;
        }

        public string FullName { get; private set; }
        public int Power { get; private set; }
        public int Level { get; private set; }
    }

    class PlayersFactory
    {
        private List<string> _firstNames = new List<string>();
        private List<string> _middleNames = new List<string>();
        private List<string> _lastNames = new List<string>();

        private int _maxLevel = 999;
        private int _maxPower = 100;

        public PlayersFactory()
        {
            _firstNames.Add("Сергей");
            _firstNames.Add("Михаил");
            _firstNames.Add("Александр");
            _firstNames.Add("Вячеслав");
            _firstNames.Add("Пётр");
            _firstNames.Add("Николай");
            _firstNames.Add("Станислав");

            _middleNames.Add("Гусев");
            _middleNames.Add("Левин");
            _middleNames.Add("Хомяков");
            _middleNames.Add("Юдин");
            _middleNames.Add("Корниненко");
            _middleNames.Add("Корпусенко");

            _lastNames.Add("Андреевич");
            _lastNames.Add("Евгеньевич");
            _lastNames.Add("Дмитреевич");
            _lastNames.Add("Тимовеевич");
            _lastNames.Add("Викторович");
            _lastNames.Add("Борисович");
        }

        public List<Player> Generate(int culpritsCount)
        {
            List<Player> sickes = new List<Player>();

            for (int i = 0; i < culpritsCount; i++)
            {
                sickes.Add(new Player(GetFullName(), Utils.GenerateNumberInRange(_maxPower), Utils.GenerateNumberInRange(_maxLevel)));
            }

            return sickes;
        }

        private string GetFullName()
        {
            string fullName, firstName, middleName, lastName;

            firstName = _firstNames[Utils.GenerateNumberInRange(_firstNames.Count)];
            middleName = _middleNames[Utils.GenerateNumberInRange(_middleNames.Count)];
            lastName = _lastNames[Utils.GenerateNumberInRange(_lastNames.Count)];

            return fullName = firstName + " " + middleName + " " + lastName;
        }
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static int GenerateNumberInRange(int maxNumber)
        {
            return s_random.Next(maxNumber++);
        }

        public static int GenerateNumberInRange(int minNumber, int maxNumber)
        {
            return s_random.Next(minNumber, maxNumber++);
        }
    }
}