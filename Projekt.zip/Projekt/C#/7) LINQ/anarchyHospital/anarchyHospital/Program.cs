﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace anarchyHospital
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SickesFactory sickesFactory = new SickesFactory();
            Hospital hospital = new Hospital(sickesFactory);

            hospital.Work();
        }
    }

    class Hospital
    {
        private List<Sick> _sickes;

        private int _sickesCount = 30;

        public Hospital(SickesFactory sickesFactory)
        {
            _sickes = sickesFactory.Generate(_sickesCount);
        }

        public void Work()
        {
            const string CommandSortSickesFullName = "1";
            const string CommandSortSickesByAge = "2";
            const string CommandEnterDisease = "3";

            bool isOpen = true;

            while (isOpen)
            {
                Console.Clear();

                ShowMenu(CommandSortSickesFullName, CommandSortSickesByAge, CommandEnterDisease);

                switch (Console.ReadLine())
                {
                    case CommandSortSickesFullName:
                        SortFullName();
                        break;
                    case CommandSortSickesByAge:
                        SortSickesByAge();
                        break;
                    case CommandEnterDisease:
                        EnterDisease();
                        break;
                    default:
                        isOpen = false;
                        break;
                }

                Console.WriteLine();
                Console.ReadKey();
            }
        }

        private void ShowMenu(string commandSortSickesFullName, string commandSortSickesByAge, string commandEnterDisease)
        {
            Console.WriteLine($"Нажмите: {commandSortSickesFullName} для сортировки больных по ФИО\n" +
                $"Нажмите: {commandSortSickesByAge} для сортировки больных по возрасту\n" +
                $"Нажмите: {commandEnterDisease} для ввода заболевания и последующего поиска им заболевших\n" +
                $"Нажмите: любую клавишу чтоб выйти.\n");
        }

        private void EnterDisease()
        {
            var diseases = _sickes.Select(sick => sick.Disease).Distinct().ToList();

            Console.Clear();
            ShowDiseases(diseases);
            string inputUser = ReadInputDisease(diseases);

            var sickes = _sickes.Where(sick => sick.Disease.ToUpper() == inputUser.ToUpper()).ToList();
            ShowInfo(sickes);
        }

        private string ReadInputDisease(List<string> diseases)
        {
            bool isWork = true;
            string inputUser = "";

            while (isWork)
            {
                Console.Write($"\nВведите название болезни из выше перечисленных:");
                inputUser = Console.ReadLine();

                if (diseases.Where(disease => disease.ToUpper() == inputUser.ToUpper()).Any() == true)
                {
                    isWork = false;
                }
            }

            return inputUser;
        }

        private void ShowDiseases(List<string> diseases)
        {
            foreach (var disease in diseases)
            {
                Console.WriteLine(disease);
            }
        }

        private void SortFullName()
        {
            var sickes = _sickes.OrderBy(sick => sick.FullName).ToList();
            ShowInfo(sickes);
        }

        private void SortSickesByAge()
        {
            var sickes = _sickes.OrderBy(sick => sick.Age).ToList();
            ShowInfo(sickes);
        }

        private void ShowInfo(List<Sick> sickes)
        {
            Console.WriteLine();

            foreach (Sick sick in sickes)
            {
                Console.WriteLine($"{sick.FullName} {sick.Age} лет {sick.Disease} ");
            }
        }
    }

    class Sick
    {
        public Sick(string fullName, int age, string disease)
        {
            FullName = fullName;
            Age = age;
            Disease = disease;
        }

        public string FullName { get; private set; }
        public int Age { get; private set; }
        public string Disease { get; private set; }
    }

    class SickesFactory
    {
        private List<string> _firstNames = new List<string>();
        private List<string> _middleNames = new List<string>();
        private List<string> _lastNames = new List<string>();
        private List<string> _diseases = new List<string>();

        private int _minAge = 8;
        private int _maxAge = 72;

        public SickesFactory()
        {
            _firstNames.Add("Сергей");
            _firstNames.Add("Михаил");
            _firstNames.Add("Александр");
            _firstNames.Add("Вячеслав");
            _firstNames.Add("Пётр");
            _firstNames.Add("Николай");
            _firstNames.Add("Станислав");

            _middleNames.Add("Гусев");
            _middleNames.Add("Левин");
            _middleNames.Add("Хомяков");
            _middleNames.Add("Юдин");
            _middleNames.Add("Корниненко");
            _middleNames.Add("Корпусенко");

            _lastNames.Add("Андреевич");
            _lastNames.Add("Евгеньевич");
            _lastNames.Add("Дмитреевич");
            _lastNames.Add("Тимовеевич");
            _lastNames.Add("Викторович");
            _lastNames.Add("Борисович");

            _diseases.Add("ОРВИ");
            _diseases.Add("Рак");
            _diseases.Add("Туберкулез");
            _diseases.Add("Сепсис");
        }

        public List<Sick> Generate(int culpritsCount)
        {
            List<Sick> sickes = new List<Sick>();

            for (int i = 0; i < culpritsCount; i++)
            {
                string disease = _diseases[Utils.GenerateNumberInRange(_diseases.Count)];

                sickes.Add(new Sick(GetFullName(), Utils.GenerateNumberInRange(_minAge, _maxAge), disease));
            }

            return sickes;
        }

        private string GetFullName()
        {
            string fullName, firstName, middleName, lastName;

            firstName = _firstNames[Utils.GenerateNumberInRange(_firstNames.Count)];
            middleName = _middleNames[Utils.GenerateNumberInRange(_middleNames.Count)];
            lastName = _lastNames[Utils.GenerateNumberInRange(_lastNames.Count)];

            return fullName = firstName + " " + middleName + " " + lastName;
        }
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static int GenerateNumberInRange(int maxNumber)
        {
            return s_random.Next(maxNumber++);
        }

        public static int GenerateNumberInRange(int minNumber, int maxNumber)
        {
            return s_random.Next(minNumber, maxNumber++);
        }
    }
}