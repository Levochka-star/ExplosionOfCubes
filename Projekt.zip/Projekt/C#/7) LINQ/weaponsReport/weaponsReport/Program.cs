﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace weaponsReport
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SolderFactory solderfactory = new SolderFactory();
            Report report = new Report(solderfactory);

            report.Work();
        }
    }

    class Report
    {
        private List<Solder> _solders = new List<Solder>();

        private int _soldersCount = 30;

        public Report(SolderFactory solderFactory)
        {
            _solders = solderFactory.Generate(_soldersCount);
        }

        public void Work()
        {
            Console.WriteLine("Имена и завания:");
            ShowInfoOfNameAndRank();
            Console.ReadKey();
        }

        private void ShowInfoOfNameAndRank()
        {
            var namesAndRangs = _solders.Select(solder => new { Name = solder.FullName, Rank = solder.Rank }).ToList();

            foreach (var nameAndRang in namesAndRangs)
            {
                Console.WriteLine($"{nameAndRang.Name}, звание: {nameAndRang.Rank}");
            }
        }
    }

    class Solder
    {
        public Solder(string fullName, string weapon, string rank, int militaryService)
        {
            FullName = fullName;
            Weapon = weapon;
            Rank = rank;
            MilitaryService = militaryService;
        }

        public string FullName { get; private set; }
        public string Weapon { get; private set; }
        public string Rank { get; private set; }
        public int MilitaryService { get; private set; }
    }

    class SolderFactory
    {
        private List<string> _firstNames = new List<string>();
        private List<string> _middleNames = new List<string>();
        private List<string> _lastNames = new List<string>();
        private List<string> _weapon = new List<string>();
        private List<string> _Rank = new List<string>();

        private int _maxMilitaryServicee = 12;

        public SolderFactory()
        {
            _firstNames.Add("Сергей");
            _firstNames.Add("Михаил");
            _firstNames.Add("Александр");
            _firstNames.Add("Вячеслав");
            _firstNames.Add("Пётр");
            _firstNames.Add("Николай");
            _firstNames.Add("Станислав");

            _middleNames.Add("Гусев");
            _middleNames.Add("Левин");
            _middleNames.Add("Хомяков");
            _middleNames.Add("Юдин");
            _middleNames.Add("Корниненко");
            _middleNames.Add("Корпусенко");

            _lastNames.Add("Андреевич");
            _lastNames.Add("Евгеньевич");
            _lastNames.Add("Дмитреевич");
            _lastNames.Add("Тимовеевич");
            _lastNames.Add("Викторович");
            _lastNames.Add("Борисович");

            _weapon.Add("Револьвер");
            _weapon.Add("Дробовик");
            _weapon.Add("Винтовка");
            _weapon.Add("Пулемёт");
            _weapon.Add("Мушкет");

            _Rank.Add("Рядовой");
            _Rank.Add("Ефрейтор");
            _Rank.Add("Младший сержант");
            _Rank.Add("Прапорщик");
            _Rank.Add("Старший прапорщик");
        }

        public List<Solder> Generate(int culpritsCount)
        {
            List<Solder> solders = new List<Solder>();

            for (int i = 0; i < culpritsCount; i++)
            {
                string weapon = _Rank[Utils.GenerateNumberInRange(_Rank.Count)];
                string rank = _Rank[Utils.GenerateNumberInRange(_Rank.Count)];

                solders.Add(new Solder(GetFullName(), weapon, rank, Utils.GenerateNumberInRange(_maxMilitaryServicee)));
            }

            return solders;
        }

        private string GetFullName()
        {
            string firstName;
            string middleName;
            string lastName;

            firstName = _firstNames[Utils.GenerateNumberInRange(_firstNames.Count)];
            middleName = _middleNames[Utils.GenerateNumberInRange(_middleNames.Count)];
            lastName = _lastNames[Utils.GenerateNumberInRange(_lastNames.Count)];

            return firstName + " " + lastName;
        }
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static int GenerateNumberInRange(int maxNumber)
        {
            return s_random.Next(maxNumber++);
        }
    }
}