﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace transferSoldiers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SolderFactory solderfactory = new SolderFactory();
            Transfer report = new Transfer(solderfactory);

            report.Work();
        }
    }

    class Transfer
    {
        private List<Solder> _solders1 = new List<Solder>();
        private List<Solder> _solders2 = new List<Solder>();

        private int _soldersCount = 10;

        public Transfer(SolderFactory solderFactory)
        {
            _solders1 = solderFactory.Generate(_soldersCount);
            _solders2 = solderFactory.Generate(_soldersCount);
        }

        public void Work()
        {
            Console.WriteLine($"Объединенные отряды: {_soldersCount} + бойцы с фамилией на \"Б\":");
            ShowInfoCombinedCollection();
            Console.ReadKey();
        }

        private void ShowInfoCombinedCollection()
        {
            int numberPoint = 0;

            var combinedCollection = _solders1.Where(solder => solder.LastName.ToUpper().StartsWith("Б")).Union(_solders2);

            foreach(var solder in combinedCollection)
            {
                Console.WriteLine($"{++numberPoint}) Имя, фамилия:{solder.FirstName} {solder.LastName} звание:{solder.Rank} отслужено:{solder.MilitaryService}");
            }
        }
    }

    class Solder
    {
        public Solder(string firstName, string lastName, string rank, int militaryService)
        {
            FirstName = firstName;
            LastName = lastName;
            Rank = rank;
            MilitaryService = militaryService;
        }

        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public string Rank { get; private set; }
        public int MilitaryService { get; private set; }
    }

    class SolderFactory
    {
        private List<string> _firstNames = new List<string>();
        private List<string> _lastNames = new List<string>();
        private List<string> _Rank = new List<string>();

        private int _maxMilitaryServicee = 12;

        public SolderFactory()
        {
            _firstNames.Add("Сергей");
            _firstNames.Add("Михаил");
            _firstNames.Add("Александр");
            _firstNames.Add("Вячеслав");
            _firstNames.Add("Пётр");
            _firstNames.Add("Николай");
            _firstNames.Add("Станислав");

            _lastNames.Add("Андреевич");
            _lastNames.Add("Евгеньевич");
            _lastNames.Add("Дмитреевич");
            _lastNames.Add("Баринов");
            _lastNames.Add("Викторович");
            _lastNames.Add("Баранов");

            _Rank.Add("Рядовой");
            _Rank.Add("Ефрейтор");
            _Rank.Add("Младший сержант");
            _Rank.Add("Прапорщик");
            _Rank.Add("Старший прапорщик");
        }

        public List<Solder> Generate(int culpritsCount)
        {
            List<Solder> solders = new List<Solder>();

            for (int i = 0; i < culpritsCount; i++)
            {
                string rank = _Rank[Utils.GenerateNumberInRange(_Rank.Count)];

                solders.Add(new Solder(_firstNames[Utils.GenerateNumberInRange(_firstNames.Count)], _lastNames[Utils.GenerateNumberInRange(_lastNames.Count)], rank, Utils.GenerateNumberInRange(_maxMilitaryServicee)));
            }

            return solders;
        }
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static int GenerateNumberInRange(int maxNumber)
        {
            return s_random.Next(maxNumber++);
        }
    }
}