﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SearchForTheCulprit
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CulpritsFactory culpritsFactory = new CulpritsFactory();
            SearchCulprits searchCulprits = new SearchCulprits(culpritsFactory);
            searchCulprits.Work();
        }
    }

    class SearchCulprits
    {
        private CulpritsAtLarge _culpritsAtLarge;

        public SearchCulprits(CulpritsFactory culpritsFactory)
        {
            _culpritsAtLarge = new CulpritsAtLarge(culpritsFactory);
        }

        public void Work()
        {
            List<string> nationalites = new List<string>();

            int heightMin = 0;
            int heightMax = 0;
            int weightMin = 0;
            int weightMax = 0;

            GetInfoFromTheUser(ref heightMin, ref heightMax, "рост", _culpritsAtLarge.HeightMin, _culpritsAtLarge.HeightMax);
            Console.WriteLine();
            GetInfoFromTheUser(ref weightMin, ref weightMax, "вес", _culpritsAtLarge.WeightMin, _culpritsAtLarge.WeightMax);
            Console.WriteLine();

            nationalites = _culpritsAtLarge.GetNationalites();

            string nationality = GetInfoFromTheUser(nationalites);

            _culpritsAtLarge.GetCulpritsBy(heightMin, heightMax, weightMin, weightMax, nationality);
            Console.WriteLine();
            _culpritsAtLarge.ShowInfo();

            Console.ReadKey();
        }

        private string GetInfoFromTheUser(List<string> nationalites)
        {
            Console.WriteLine($"Ведите национальность преступника из данных ниже:");
            ShowNationalites(nationalites);
            Console.WriteLine();
            string nationality = _culpritsAtLarge.GetCulpritsByNationalites(Console.ReadLine());
            return nationality;
        }

        private void GetInfoFromTheUser(ref int valueMin, ref int valueMax, string arg, int minValueArg, int maxValueArg)
        {
            Console.WriteLine($"Ведите {arg} преступника (от {minValueArg} до {maxValueArg}):");
            Console.Write($"Минимальный {arg}:");
            valueMin = Utils.GetNumberPositiveInRange(minValueArg, maxValueArg);
            Console.Write($"Максимальный {arg}:");
            valueMax = Utils.GetNumberPositiveInRange(valueMin, maxValueArg);
        }

        private void ShowNationalites(List<string> nationalites)
        {
            for (int i = 0; i < nationalites.Count; i++)
            {
                Console.WriteLine(nationalites[i]);
            }
        }
    }

    class CulpritsAtLarge
    {
        private List<Culprit> _culprits;

        private int _culpritsCount = 1000;

        public CulpritsAtLarge(CulpritsFactory culpritsFactory)
        {
            _culprits = culpritsFactory.Generate(_culpritsCount).Where(culprit => culprit.IsPlanted == false).ToList();
        }

        public int HeightMin => _culprits.Min(culprit => culprit.Height);
        public int HeightMax => _culprits.Max(culprit => culprit.Height);
        public int WeightMin => _culprits.Min(culprit => culprit.Weight);
        public int WeightMax => _culprits.Max(culprit => culprit.Weight);


        public void GetCulpritsBy(int minHeight, int maxHeight, int minWeight, int maxWeight, string nationality)
        {
            _culprits = _culprits.Where(culprit => culprit.Height >= minHeight && culprit.Height <= maxHeight &&
            culprit.Weight >= minWeight && culprit.Weight <= maxWeight &&
            culprit.Nationality == nationality).ToList();
        }

        public string GetCulpritsByNationalites(string nationality)
        {
            bool isOpen = true;

            List<string> nationalites = GetNationalites();

            while (isOpen)
            {
                for (int i = 0; i < nationalites.Count; i++)
                {
                    if (nationalites[i] == nationality)
                    {
                        isOpen = false;
                    }
                }

                if (isOpen == true)
                {
                    Console.WriteLine("Ввод неверный! Попробуй снова:");
                    nationality = Console.ReadLine();
                }
            }

            return nationality;
        }

        public List<string> GetNationalites()
        {
            List<string> nationalites = _culprits.Select(culprit => culprit.Nationality).Distinct().ToList();

            return CloneList(nationalites);
        }

        public void ShowInfo()
        {
            string free = "на свободе";
            string closed = "сидит";

            if (_culprits.Count > 0)
            {
                for (int i = 0; i < _culprits.Count; i++)
                {
                    string plant = (_culprits[i].IsPlanted == false) ? free : closed;
                    Console.WriteLine($"{_culprits[i].FullName} {plant}|рост:{_culprits[i].Height}|вес:{_culprits[i].Weight}|нация:{_culprits[i].Nationality}");
                }
            }
            else
            {
                Console.WriteLine("Таких нет(");
            }
        }

        private List<string> CloneList(List<string> inputNationalites)
        {
            List<string> nationalites = new List<string>();

            for (int i = 0; i < inputNationalites.Count; i++)
            {
                nationalites.Add(inputNationalites[i]);
            }

            return nationalites;
        }
    }

    class Culprit
    {
        public Culprit(string fullName, bool isPlanted, int height, int weight, string nationalites)
        {
            FullName = fullName;
            IsPlanted = isPlanted;
            Height = height;
            Weight = weight;
            Nationality = nationalites;
        }

        public string FullName { get; private set; }
        public bool IsPlanted { get; private set; }
        public int Height { get; private set; }
        public int Weight { get; private set; }
        public string Nationality { get; private set; }
    }

    class CulpritsFactory
    {
        private int _heightMin = 160;
        private int _heightMax = 200;
        private int _weightMin = 77;
        private int _weightMax = 120;

        private List<string> _firstNames = new List<string>();
        private List<string> _middleNames = new List<string>();
        private List<string> _lastNames = new List<string>();
        private List<string> _nationalites = new List<string>();

        public CulpritsFactory()
        {
            _firstNames.Add("Сергей");
            _firstNames.Add("Михаил");
            _firstNames.Add("Александр");
            _firstNames.Add("Вячеслав");
            _firstNames.Add("Пётр");

            _middleNames.Add("Гусев");
            _middleNames.Add("Левин");
            _middleNames.Add("Хомяков");
            _middleNames.Add("Юдин");
            _middleNames.Add("Корниненко");

            _lastNames.Add("Андреевич");
            _lastNames.Add("Евгеньевич");
            _lastNames.Add("Дмитреевич");
            _lastNames.Add("Тимовеевич");
            _lastNames.Add("Викторович");

            _nationalites.Add("Армян");
            _nationalites.Add("Туркмен");
            _nationalites.Add("Болгар");
            _nationalites.Add("Осетин");
        }

        public List<Culprit> Generate(int culpritsCount)
        {
            List<Culprit> culprits = new List<Culprit>();

            for (int i = 0; i < culpritsCount; i++)
            {
                int height = Utils.GenerateNumberInRange(_heightMin, _heightMax);
                int weight = Utils.GenerateNumberInRange(_weightMin, _weightMax);

                string nationality = _nationalites[Utils.GenerateNumberInRange(_nationalites.Count)];
                culprits.Add(new Culprit(GetFullName(), GetIsPlanted(), height, weight, nationality));
            }

            return culprits;
        }

        private string GetFullName()
        {
            string fullName, firstName, middleName, lastName;

            firstName = _firstNames[Utils.GenerateNumberInRange(_firstNames.Count)];
            middleName = _middleNames[Utils.GenerateNumberInRange(_middleNames.Count)];
            lastName = _lastNames[Utils.GenerateNumberInRange(_lastNames.Count)];

            return fullName = firstName + " " + middleName + " " + lastName;
        }

        private bool GetIsPlanted()
        {
            bool[] isPlanted = new bool[] { true, false };

            return isPlanted[Utils.GenerateNumberInRange(isPlanted.Length)];
        }
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static int GenerateNumberInRange(int maxNumber)
        {
            return s_random.Next(maxNumber++);
        }

        public static int GenerateNumberInRange(int minNumber, int maxNumber)
        {
            return s_random.Next(minNumber, maxNumber++);
        }

        public static int GetNumberPositiveInRange(int minNumber, int maxNumber)
        {
            bool isOpen = true;
            string inputUser;
            int result = 0;

            while (isOpen)
            {
                inputUser = Console.ReadLine();

                if (int.TryParse(inputUser, out result) && result >= minNumber && result <= maxNumber)
                {
                    isOpen = false;
                }
                else
                {
                    Console.Write("\nТакого нет.\nПопробуй ввести сейчас: ");
                }
            }

            return result;
        }
    }
}