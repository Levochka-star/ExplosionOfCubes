﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace definitionOfDelay
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StewFactory stewFactory = new StewFactory();
            Sorter sorter = new Sorter(stewFactory);

            sorter.Work();
        }
    }

    class Sorter
    {
        private List<Stew> _stews = new List<Stew>();

        private int _stewsCount = 30;
        private int _currentYear = 2025;

        public Sorter(StewFactory stewFactory)
        {
            _stews = stewFactory.Generate(_stewsCount);
        }

        public void Work()
        {
            Console.WriteLine("Просточенные банки тушенки:");
            FindDelays();

            Console.ReadKey();
        }

        public void FindDelays()
        {
            var delayStews = _stews.Where(stew => stew.Expiration < _currentYear).ToList();

            ShowStews(delayStews);
        }

        private void ShowStews(List<Stew> stews)
        {
            foreach (var stew in stews)
            {
                Console.WriteLine($"{stew.Name} || Дата изготовления: {stew.Age} Годен до: {stew.Expiration} ");
            }
        }
    }

    class Stew
    {
        public Stew(string name, int age, int expiration)
        {
            Name = name;
            Age = age;
            Expiration = expiration;
        }

        public string Name { get; private set; }
        public int Age { get; private set; }
        public int Expiration { get; private set; }
    }

    class StewFactory
    {
        private List<string> _firstNames = new List<string>();
        private List<string> _lastNames = new List<string>();

        private int _minYearProduction = 1980;
        private int _maxYearProduction = 2000;
        private int _expiration = 2040;

        public StewFactory()
        {
            _firstNames.Add("Тушенка");
            _firstNames.Add("Мясо - тушенка");

            _lastNames.Add("Андреевский продукт");
            _lastNames.Add("Александровка");
            _lastNames.Add("Бабушкина");
            _lastNames.Add("Деревенская");
            _lastNames.Add("Натуральная");
            _lastNames.Add("Царская");
        }

        public List<Stew> Generate(int culpritsCount)
        {
            List<Stew> sickes = new List<Stew>();

            for (int i = 0; i < culpritsCount; i++)
            {
                sickes.Add(new Stew(GetFullName(), Utils.GenerateNumberInRange(_minYearProduction, _maxYearProduction), Utils.GenerateNumberInRange(_maxYearProduction, _expiration)));
            }

            return sickes;
        }

        private string GetFullName()
        {
            string firstName;
            string lastName;

            firstName = _firstNames[Utils.GenerateNumberInRange(_firstNames.Count)];
            lastName = _lastNames[Utils.GenerateNumberInRange(_lastNames.Count)];

            return firstName + " " + lastName;
        }
    }

    class Utils
    {
        private static Random s_random = new Random();

        public static int GenerateNumberInRange(int maxNumber)
        {
            return s_random.Next(maxNumber++);
        }

        public static int GenerateNumberInRange(int minNumber, int maxNumber)
        {
            return s_random.Next(minNumber, maxNumber++);
        }
    }
}