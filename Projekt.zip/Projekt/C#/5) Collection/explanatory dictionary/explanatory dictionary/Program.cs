﻿using System;
using System.Collections.Generic;

namespace explanatory_dictionary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string inputUser;

            bool isOpen = true;

            Dictionary<string, string> dictionaryMaterials = new Dictionary<string, string>();

            FillDictionaryMaterials(dictionaryMaterials);

            Console.WriteLine("Введите один из ниже перечисленных материалов с большой буквы." +
                "\nЕсли вы введете неверно, то программа закроется!");

            Console.WriteLine();

            ShowDictionary(dictionaryMaterials);

            Console.WriteLine();

            while (isOpen)
            {
                inputUser = GetKey();

                bool isCorrectInput = false;

                isCorrectInput = SearchKey(inputUser, dictionaryMaterials);

                isOpen = IsCorrectInput(isOpen, isCorrectInput);
            }

            Console.ReadKey();
        }

        static void ShowDictionary(Dictionary<string, string> dictionaryMaterials)
        {
            foreach (string key in dictionaryMaterials.Keys)
            {
                Console.Write(key + " ");
            }
        }

        static bool IsCorrectInput(bool isOpen, bool IsCorrectInput)
        {
            if (IsCorrectInput == false)
            {
                Console.WriteLine("Вы ввели неверно");
                isOpen = false;
            }

            return isOpen;
        }

        static bool SearchKey(string inputUser, Dictionary<string, string> dictionaryMaterials)
        {
            bool isCorrectInput = false;

            if (dictionaryMaterials.ContainsKey(inputUser))
            {
                Console.WriteLine(dictionaryMaterials[inputUser]);
                isCorrectInput = true;
            }

            return isCorrectInput;
        }

        static string GetKey()
        {
            Console.WriteLine();

            return Console.ReadLine();
        }

        static void FillDictionaryMaterials(Dictionary<string, string> dictionaryMaterials)
        {
            dictionaryMaterials.Add("Дерево", "Бумага");
            dictionaryMaterials.Add("Нефть", "Бензин");
            dictionaryMaterials.Add("Чугун", "Сталь");
        }
    }
}