﻿using System;
using System.Collections.Generic;

namespace Advanced_personnel_accounting
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string CommandAddDossier = "1";
            const string CommandDeliteDossier = "2";
            const string CommandExit = "3";

            Dictionary<string, List<string>> dosiers = new Dictionary<string, List<string>>();

            int numberXPositionInput = 5;

            bool isWork = true;

            while (isWork)
            {
                Console.Clear();

                DrawMenu(CommandAddDossier, CommandDeliteDossier, CommandExit);

                DrawDossiers(dosiers);

                Console.SetCursorPosition(0, numberXPositionInput);

                switch (ReadLine())
                {
                    case CommandAddDossier:
                        AddDossier(dosiers);
                        break;

                    case CommandDeliteDossier:
                        DeliteDossier(dosiers);
                        break;

                    case CommandExit:
                        isWork = false;
                        break;
                }
            }
        }

        static void DrawMenu(string CommandAddDossier, string CommandDeliteDossier, string CommandExit)
        {
            Console.WriteLine($"Введите номер, требуемого пункта меню:\n" +
                $"{CommandAddDossier}) Добавить досье.\n" +
                $"{CommandDeliteDossier}) Удалить досье.\n" +
                $"{CommandExit}) Выход.");
        }

        static void AddDossier(Dictionary<string, List<string>> dossiers)
        {
            string post;
            string fullName;

            Console.WriteLine();
            Console.Write("Введите должность сотрудника: ");

            post = ReadLine();

            Console.Write("Введите полное имя сотрудника: ");

            fullName = ReadLine();

            if (dossiers.ContainsKey(post) == false)
            {
                dossiers[post] = new List<string>();
            }

            dossiers[post].Add(fullName);
        }

        static void DrawDossiers(Dictionary<string, List<string>> dossiers)
        {
            int number;
            int numberXPosition = 60;
            int numberYPosition = -2;

            foreach (var item in dossiers)
            {
                numberYPosition += 2;

                Console.SetCursorPosition(numberXPosition, numberYPosition);

                Console.WriteLine(item.Key);

                number = 0;

                for (int i = 0; i < item.Value.Count; i++)
                {
                    numberYPosition++;
                    number++;

                    Console.SetCursorPosition(numberXPosition, numberYPosition);

                    Console.WriteLine($"{number}) {item.Value[i]}");
                }
            }
        }

        static void DeliteDossier(Dictionary<string, List<string>> dossiers)
        {
            string post;
            int numberPerson;

            if (dossiers.Keys.Count != 0)
            {
                Console.WriteLine();
                Console.Write("Введите должность сотрудника: ");

                post = ReadLine();

                if (dossiers.ContainsKey(post) == true)
                {
                    Console.Write("Введите НОМЕР сотрудника: ");

                    numberPerson = ReadInt();

                    List<string> persons = dossiers[post];

                    if (numberPerson > 0 && numberPerson <= persons.Count)
                    {
                        persons.RemoveAt(numberPerson -= 1);
                    }
                    else
                    {
                        Console.WriteLine("Неправильно указан номер. Нажмите любую клавишу..");
                        Console.ReadKey();
                    }

                    if (persons.Count == 0)
                    {
                        dossiers.Remove(post);
                    }
                }
                else
                {
                    Console.WriteLine("\nТакой должности нет");
                    Console.ReadKey();
                }
            }
            else
            {
                Console.WriteLine("\nДосье нет! Для начала добавьте досье.");
                Console.ReadKey();
            }
        }

        static string ReadLine()
        {
            bool isOpen = true;

            string inputUser = "Ошибка";

            while (isOpen)
            {
                inputUser = Console.ReadLine();

                if (inputUser == "")
                {
                    Console.WriteLine("Вы ничего не ввели!");
                    Console.Write("Попробуйте снова: ");
                }
                else
                {
                    isOpen = false;
                }
            }

            return inputUser;
        }

        static int ReadInt()
        {
            bool isOpen = true;
            string inputNumber;
            int results = 0;

            inputNumber = Console.ReadLine();

            while (isOpen)
            {
                if (int.TryParse(inputNumber, out int number))
                {
                    results = number;
                    isOpen = false;
                }
                else
                {
                    Console.WriteLine($"Попробуйте снова! Нажмите любую клавишу");
                    inputNumber = Console.ReadLine();
                }
            }

            return results;
        }
    }
}