﻿using System;
using System.Collections.Generic;

namespace Advanced_dynamic_array
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string CommandSumNumbers = "sum";
            const string CommandExit = "exit";

            List<int> numbers = new List<int>();

            bool isOpen = true;

            while (isOpen)
            {
                Console.Clear();

                DrawArrayNumbers(numbers);
                DrawConsoleMenu(CommandSumNumbers, CommandExit);

                string inputUser = Console.ReadLine();

                switch (inputUser)
                {
                    case CommandSumNumbers:
                        ShowSumNumbers(numbers);

                        Console.WriteLine("Нажмите любую клавишу...");
                        Console.ReadKey();
                        break;

                    case CommandExit:
                        isOpen = false;
                        break;

                    default:
                        numbers.Add(ReadInt(inputUser));
                        break;
                }
            }
        }

        static void RepaintWriteLine(int number, ConsoleColor Color = ConsoleColor.Green)
        {
            ConsoleColor defaultColor = Console.ForegroundColor;
            Console.ForegroundColor = Color;

            Console.WriteLine(number);

            Console.ForegroundColor = defaultColor;
        }

        static void DrawConsoleMenu(string CommandSumNumbers, string CommandExit)
        {
            Console.WriteLine($"\nСложить числа - {CommandSumNumbers}." +
                                $"\nВыйти из программы - {CommandExit}.\n");
        }

        static void DrawArrayNumbers(List<int> numbers)
        {
            if (ReadEmptyArray(numbers))
            {
                Console.WriteLine();

                for (int i = 0; i < numbers.Count; i++)
                {
                    RepaintWriteLine(numbers[i]);
                }

                Console.WriteLine();
            }
        }

        static void ShowSumNumbers(List<int> numbers)
        {
            int sumNumbers = 0;

            Console.Write("\nСумма введеный чисел равняется: ");

            for (int i = 0; i < numbers.Count; i++)
            {
                sumNumbers += numbers[i];
            }

            RepaintWriteLine(sumNumbers, ConsoleColor.Blue);
            Console.WriteLine();
        }

        static int ReadInt(string inputUser)
        {
            bool isOpen = true;
            int result = 0;

            while (isOpen)
            {
                if (int.TryParse(inputUser, out int number))
                {
                    result = number;
                    isOpen = false;
                }
                else
                {
                    Console.WriteLine("\nВведено не число, попробуй снова.\n");
                }
            }

            return result;
        }

        static bool ReadEmptyArray(List<int> numbers)
        {
            bool isOpen = false;

            if (numbers.Count < 1)
            {
                Console.WriteLine("\nПока не введено ни одного числа\n");
            }
            else
            {
                isOpen = true;
            }

            return isOpen;
        }
    }
}