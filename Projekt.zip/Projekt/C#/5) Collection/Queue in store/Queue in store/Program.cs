﻿using System;
using System.Collections.Generic;

namespace Queue_in_store
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int myVallet = 0;
            int valueBasket = 10;

            Queue<int> baskets = new Queue<int>();

            FillQueue(baskets, valueBasket);

            while (baskets.Count > 0)
            {
                int costBasket = 0;
                int clientNumber = 1;

                Console.Clear();

                ShowMoney(myVallet);

                DrawQueue(baskets, clientNumber);

                costBasket = DrawMenu(baskets);

                myVallet = SumMoney(myVallet, costBasket);
            }

            Console.Clear();
            Console.WriteLine($"Денег в кошельке: {myVallet}");

            Console.ReadKey();
        }

        static int DrawMenu(Queue<int> baskets)
        {
            int costBasket;

            Console.SetCursorPosition(0, 0);

            Console.WriteLine($"\"Обслуживание\"");
            Console.WriteLine($"Cумма покупки: {costBasket = baskets.Dequeue()} з. " +
                $"\n(любая клавиша)");

            Console.ReadKey();

            return costBasket;
        }

        static void DrawQueue(Queue<int> baskets, int clientNumber)
        {
            Console.SetCursorPosition(0, 5);

            foreach (int basket in baskets)
            {
                Console.WriteLine($"Клиент {clientNumber++}, сумма покупки: {basket}");
            }
        }

        static void ShowMoney(int myVallet)
        {
            Console.SetCursorPosition(45, 0);

            Console.WriteLine($"Денег в кошельке: {myVallet}");
        }

        static int SumMoney(int moneyInVallet, int costBasket)
        {
            moneyInVallet += costBasket;

            return moneyInVallet;
        }

        static void FillQueue(Queue<int> baskets, int valueBasket)
        {
            Random random = new Random();

            for (int i = 0; i < valueBasket; i++)
            {
                int minValue = 1;
                int maxValue = 100;

                baskets.Enqueue(random.Next(minValue, maxValue++));
            }
        }
    }
}