﻿using System;
using System.Collections.Generic;

namespace Merging_into_one_collection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers1 = new int[] { 1, 4, 3, 5, 2, 3, 5, 9 };
            int[] numbers2 = new int[] { 2, 1, 4, 3, 5, 6, 4, 2 };

            List<int> numbers = new List<int>();

            Console.Write("Первый массив: ");
            DrawArrayNumbers(numbers1);

            Console.Write("Второй массив: ");
            DrawArrayNumbers(numbers2);

            AddNumbersInList(numbers1, numbers);
            AddNumbersInList(numbers2, numbers);

            Console.Write("Список из чисел без повторений: ");
            DrawListNumbers(numbers);

            Console.ReadKey();
        }

        static void AddNumbersInList(int[] numbersArray, List<int> numbersList)
        {
            for (int i = 0; i < numbersArray.Length; i++)
            {
                if (numbersList.Contains(numbersArray[i]) == false)
                {
                    numbersList.Add(numbersArray[i]);
                }
            }
        }
        
        static void DrawListNumbers(List<int> numbers)
        {
            for (int i = 0; i < numbers.Count; i++)
            {
                Console.Write(numbers[i] + " ");
            }

            Console.WriteLine();
        }

        static void DrawArrayNumbers(int[] numbers)
        {
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.Write(numbers[i] + " ");
            }

            Console.WriteLine();
        }
    }
}